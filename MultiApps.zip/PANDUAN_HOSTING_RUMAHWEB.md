# Panduan Lengkap Pemasangan MultiApps Solutions di Hosting Rumahweb (Database SQLite)

Panduan ini disusun khusus untuk memudahkan Anda memasang dan menjalankan website **MultiApps Solutions** di layanan hosting **Rumahweb Indonesia** (baik paket Shared Hosting cPanel, Cloud Hosting, maupun DirectAdmin) menggunakan database **SQLite 3**.

---

## 🌟 Keunggulan Menggunakan Database SQLite di Rumahweb

1. **Zero Configuration (Instan & Mandiri):**
   Tidak perlu membuat database, user database, dan password MySQL di cPanel. Database SQLite langsung aktif secara otomatis saat website pertama kali dibuka.
2. **Portabilitas 100%:**
   Seluruh data katalog, pesanan, dan konfigurasi tersimpan rapi dalam 1 file (`database/multiapps.sqlite`). Jika ingin pindah hosting atau backup, cukup unduh 1 file tersebut.
3. **Sangat Ringan & Cepat:**
   SQLite bekerja langsung di dalam proses PHP (*in-process engine*), sehingga response time website sangat cepat dan hemat penggunaan RAM hosting.
4. **Keamanan Terjamin:**
   File database diproteksi oleh file `.htaccess` tingkat server dengan aturan `Require all denied`, sehingga pengunjung luar tidak bisa mengunduh file database secara langsung melalui browser.

---

## 📋 Prasyarat di cPanel Rumahweb

- **Versi PHP:** PHP 7.4, 8.0, 8.1, 8.2, atau 8.3 (Sangat disarankan **PHP 8.1 ke atas**).
- **Ekstensi PHP Aktif:**
  - `pdo_sqlite` *(default sudah aktif di Rumahweb)*
  - `sqlite3` *(default sudah aktif)*
  - `curl`
  - `mbstring`
  - `fileinfo` (untuk upload gambar)

---

## 🚀 Langkah-Langkah Pemasangan di Hosting Rumahweb

### Langkah 1: Siapkan File ZIP Aplikasi
1. Buka folder proyek ini di komputer Anda (`c:\laragon\www\multiapps`).
2. Pilih semua file dan folder berikut:
   - `admin/`
   - `api/`
   - `database/`
   - `includes/`
   - `uploads/`
   - `.htaccess`
   - `index.php`
3. Klik kanan dan pilih **Compress to ZIP** (beri nama misalnya `multiapps.zip`).

> **PENTING:** Pastikan file tersembunyi seperti `.htaccess` ikut terkompres ke dalam ZIP!

---

### Langkah 2: Unggah ke File Manager cPanel Rumahweb
1. Buka browser dan login ke **cPanel Rumahweb** Anda (biasanya `https://domainanda.com:2083` atau melalui Client Area Rumahweb).
2. Cari dan klik menu **File Manager**.
3. Masuk ke direktori tujuan:
   - Jika untuk **Domain Utama**, masuk ke folder `public_html/`.
   - Jika untuk **Subdomain / Addon Domain**, masuk ke folder root subdomain tersebut (misalnya `public_html/katalog/`).
4. Klik tombol **Upload** di bilah atas cPanel.
5. Pilih file `multiapps.zip` yang telah disiapkan dan tunggu hingga proses unggah selesai (indikator bar hijau 100%).
6. Kembali ke File Manager, klik kanan pada file `multiapps.zip` dan pilih **Extract** (Ekstrak di direktori saat ini).

---

### Langkah 3: Periksa Izin Folder (File Permissions)
Agar PHP dapat membuat dan memperbarui file database SQLite serta menyimpan gambar upload:
1. Pastikan folder **`database/`** memiliki permission **`755`** (atau `775`).
2. Pastikan folder **`uploads/`** memiliki permission **`755`** (atau `775`).
3. *(Catatan: Di hosting Rumahweb dengan suPHP / ea-php, izin 755 adalah standar bawaan cPanel dan sudah dapat ditulisi secara otomatis).*

---

### Langkah 4: Periksa Pengaturan Versi PHP di cPanel
1. Di halaman utama cPanel Rumahweb, cari menu **Select PHP Version** atau **MultiPHP Manager**.
2. Pastikan domain Anda menggunakan **PHP 8.1**, **8.2**, atau **8.3**.
3. Di tab **Extensions**, pastikan modul **`pdo_sqlite`** dan **`sqlite3`** dalam status tercentang (aktif).

---

### Langkah 5: Buka Website di Browser (Auto-Install)
1. Buka domain Anda di browser:
   ```
   https://domainanda.com
   ```
2. Aplikasi akan **secara otomatis membuat file database SQLite** (`database/multiapps.sqlite`) beserta seluruh tabel, kategori bawaan, katalog aplikasi siap pakai, testimoni, FAQ, dan akun administrator.
3. Website MultiApps Solutions Anda sekarang sudah aktif dan siap menerima pengunjung! 🎉

---

## 🔐 Kredensial Login Administrator Default

Setelah website live, masuk ke panel pengelola untuk mengganti password dan konfigurasi:

- **URL Login Admin:** `https://domainanda.com/admin/login.php`
- **Username:** `admin`
- **Password:** `admin123`

---

## ⚙️ Konfigurasi Pertama Setelah Instalasi

Setelah login ke Panel Admin:
1. Masuk ke menu **Pengaturan Website** (`/admin/settings.php`).
2. **Ganti Nomor WhatsApp Tujuan:**
   - Isi nomor WhatsApp Anda dengan format `628...` (misal: `6281234567890`).
   - Setiap pelanggan yang menekan tombol *Order* atau mengisi formulir akan otomatis terhubung ke WhatsApp ini dengan pesan pemesanan yang rapi.
3. **Perbarui Kata Sandi Administrator:**
   - Di bagian bawah halaman Pengaturan, masukkan password lama (`admin123`) dan tentukan password baru yang aman.
4. **Sesuaikan Nama Bisnis, Email, & Alamat Kantor.**

---

## 📦 Ringkasan Fitur Lengkap yang Telah Berfungsi

### 1. Halaman Depan Publik (Frontend)
- **Hero & Pencarian Langsung:** Pengunjung dapat mencari aplikasi berdasarkan nama atau kata kunci (*POS, HRIS, SIMRS, Toko Online*).
- **Filter Kategori Dinamis:** Tab filter horizontal responsif (POS & Kasir, ERP & HRIS, E-Commerce, SIMRS, Sekolah, Fintech, Logistik).
- **Pengurutan Fleksibel:** Urutkan berdasarkan Populer/Unggulan, Harga Termurah, Harga Tertinggi, atau Abjad A-Z.
- **Modal Detail Aplikasi Interaktif:** Menampilkan gambar pratinjau, lisensi, platform, versi, checklist fitur utama, tombol *Coba Demo*, dan tombol *Pesan Aplikasi Ini*.
- **Pemesanan Terintegrasi Database & WhatsApp:** 
  - Saat pengunjung mengirim formulir pesan, data otomatis tersimpan di SQLite dengan **Kode Tiket Unik** (contoh: `INQ-20261107-A1B2`).
  - Muncul tombol langsung **Lanjut Chat WhatsApp** dengan pesan otomatis yang sudah terisi nama, no. tiket, dan aplikasi yang diinginkan.
- **Fitur Cek Status Tiket / Pesanan (Public Tracking):**
  - Klien dapat memasukkan nomor WhatsApp atau kode tiket mereka di tombol **"Cek Pesanan"** untuk memantau status pesanan (Baru, Diproses, Selesai) serta membaca catatan balasan dari admin.
- **Section Keunggulan & Testimoni Klien.**
- **Accordion Tanya Jawab (FAQ) Interaktif.**
- **Tombol Melayang (Floating) WhatsApp** di pojok kiri bawah.

### 2. Panel Admin (Backend Pengelola)
- **Dashboard Ringkasan:** Statistik total aplikasi, pesanan baru masuk, total pesanan, kategori, dan monitoring ukuran database SQLite.
- **Katalog Aplikasi (CRUD Penuh):**
  - Tambah, edit, hapus aplikasi.
  - Upload gambar dari komputer atau input URL eksternal (Unsplash, dll).
  - Satu-klik toggle badge *Unggulan (Featured)* dan status *Aktif / Draft*.
  - Fitur duplikasi aplikasi.
- **Kategori Aplikasi (CRUD):** Tambah, ubah nama/slug/ikon FontAwesome, dan proteksi penghapusan jika kategori masih memiliki aplikasi.
- **Manajemen Pesanan & Inquiry Masuk:**
  - Filter status: *Semua, Baru, Diproses, Selesai, Dibatalkan*.
  - Ubah status pesanan dan simpan catatan internal.
  - Tombol **1-Klik Balas via WhatsApp** (otomatis membuka WhatsApp Web / Mobile dengan template sapaan profesional).
  - Ekspor seluruh data pesanan ke file **CSV / Excel**.
  - Bersihkan pesanan batal.
- **Manajemen Testimoni:** Kelola ulasan klien, rating bintang 1-5, dan sembunyikan/tampilkan testimoni.
- **Manajemen FAQ:** Tambah dan kelola daftar tanya jawab yang tampil di beranda.
- **Backup & Optimasi Database SQLite:**
  - Tombol 1-klik untuk mengunduh cadangan file `multiapps.sqlite` ke komputer Anda.
  - Tombol 1-klik untuk menjalankan perintah optimasi `VACUUM` dan `ANALYZE` pada SQLite.

---

## 🛠️ Tanya & Jawab Masalah Umum (Troubleshooting)

### Q: Muncul pesan error "Database Connection Error" atau "attempt to write a readonly database"
> **Solusi:** Di cPanel File Manager Rumahweb, klik kanan pada folder `database/` lalu pilih **Change Permissions**. Pastikan dicentang sehingga bernilai **`755`** (atau `775`). Pastikan juga file `multiapps.sqlite` di dalamnya berizin `644` (atau `664`).

### Q: Gambar yang diunggah tidak muncul
> **Solusi:** Pastikan folder `uploads/` dan `uploads/apps/` memiliki permission `755`.

### Q: Bagaimana cara memindahkan data dari localhost ke hosting Rumahweb?
> **Solusi:** Anda cukup mengunggah file `database/multiapps.sqlite` dari komputer Anda ke folder `database/` di hosting. Seluruh data produk, kategori, dan pesanan akan langsung berpindah 100% tanpa perlu export-import SQL!

---

*MultiApps Solutions - Siap Live di Rumahweb Hosting.*
