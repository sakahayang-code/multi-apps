<?php
/**
 * MultiApps Solutions - Modern Catalog & Web Application
 * Powered by PHP & SQLite Database
 * Compatible with Rumahweb Hosting
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

$pdo = get_db();

// 1. Fetch Settings
$settings = get_all_settings();
$site_title = $settings['site_title'] ?? 'MultiApps Solutions';
$site_tagline = $settings['site_tagline'] ?? 'Katalog Aplikasi Modern & Solusi Digital';
$hero_title = $settings['hero_title'] ?? 'Solusi Software & Aplikasi Sistem untuk Pertumbuhan Bisnis Anda';
$hero_subtitle = $settings['hero_subtitle'] ?? 'Temukan ratusan opsi aplikasi siap pakai, sistem custom enterprise, hingga web app modern yang disesuaikan dengan kebutuhan bisnis skala kecil hingga besar.';
$hero_badge = $settings['hero_badge'] ?? 'Penyedia Sistem & Software Terlengkap';
$contact_email = $settings['contact_email'] ?? 'support@multiapps.id';
$contact_phone = $settings['contact_phone'] ?? '+62 812-3456-7890';
$contact_whatsapp = $settings['contact_whatsapp'] ?? '6281234567890';
$contact_address = $settings['contact_address'] ?? 'Jakarta Tech Park, Tower A Fl 8, Jakarta';
$whatsapp_greeting = $settings['whatsapp_greeting'] ?? 'Halo MultiApps Solutions, saya ingin konsultasi mengenai aplikasi: ';

// 2. Fetch Categories
$categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order ASC, name ASC")->fetchAll();

// 3. Fetch Active Apps with Category Names
$apps = $pdo->query("SELECT a.*, c.name as category_name, c.slug as category_slug 
                     FROM apps a 
                     LEFT JOIN categories c ON a.category_id = c.id 
                     WHERE a.is_active = 1 
                     ORDER BY a.is_featured DESC, a.sort_order ASC, a.id DESC")->fetchAll();

// Process apps data for JSON client-side searching & filtering
$apps_json_data = [];
foreach ($apps as $app) {
    $features_arr = array_filter(array_map('trim', preg_split("/\r\n|\n|\r|,/", $app['features'] ?: '')));
    $fallback_img = 'https://placehold.co/600x400/0284c7/white?text=' . urlencode($app['title']);
    $img_url = $app['image'] ? (strpos($app['image'], 'http') === 0 ? $app['image'] : base_url($app['image'])) : $fallback_img;

    $apps_json_data[] = [
        'id' => $app['id'],
        'title' => $app['title'],
        'slug' => $app['slug'],
        'category_id' => $app['category_id'],
        'category' => $app['category_name'] ?: 'Umum',
        'price' => (float)$app['price'],
        'price_formatted' => format_rupiah($app['price']),
        'price_label' => $app['price_label'] ?: 'Mulai dari',
        'image' => $img_url,
        'description' => $app['description'] ?: '',
        'full_description' => $app['full_description'] ?: $app['description'] ?: '',
        'features' => array_values($features_arr),
        'tech_stack' => $app['tech_stack'] ?: 'PHP, Tailwind, SQLite',
        'platform' => $app['platform'] ?: 'Web & Mobile',
        'version' => $app['version'] ?: 'v1.0.0',
        'license' => $app['license'] ?: 'Lisensi Seumur Hidup',
        'demo_url' => $app['demo_url'] ?: '',
        'is_featured' => (bool)$app['is_featured']
    ];
}

// 4. Fetch Active Testimonials
$testimonials = $pdo->query("SELECT * FROM testimonials WHERE is_active = 1 ORDER BY sort_order ASC, id DESC")->fetchAll();

// 5. Fetch Active FAQs
$faqs = $pdo->query("SELECT * FROM faqs WHERE is_active = 1 ORDER BY sort_order ASC, id ASC")->fetchAll();

// 6. Fetch Site Logo & Favicon
$site_logo = get_site_logo();
$site_favicon = get_site_favicon();
?>
<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($site_title) ?> - <?= htmlspecialchars($site_tagline) ?></title>
    <meta name="description" content="<?= htmlspecialchars($settings['meta_description'] ?? $hero_subtitle) ?>">
    
    <!-- Favicon (Otomatis Terkoneksi dengan Logo) -->
    <?php if (!empty($site_favicon)): ?>
        <link rel="icon" href="<?= htmlspecialchars($site_favicon) ?>">
        <link rel="shortcut icon" href="<?= htmlspecialchars($site_favicon) ?>">
        <link rel="apple-touch-icon" href="<?= htmlspecialchars($site_favicon) ?>">
    <?php else: ?>
        <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' rx='20' fill='%230284c7'/><path d='M50 20 L80 35 L80 65 L50 80 L20 65 L20 35 Z' fill='%23ffffff'/></svg>">
    <?php endif; ?>
    
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            50: '#f0f7ff',
                            100: '#e0effe',
                            500: '#0284c7',
                            600: '#0284c7',
                            700: '#0369a1',
                            800: '#075985',
                            900: '#0c4a6e',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .glass-header {
            background: rgba(255, 255, 255, 0.90);
            backdrop-filter: blur(14px);
        }
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f5f9;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 font-sans antialiased min-h-screen flex flex-col justify-between selection:bg-blue-600 selection:text-white">

    <!-- Toast Notification System -->
    <div id="toast-container" class="fixed bottom-5 right-5 z-50 flex flex-col gap-2 pointer-events-none"></div>

    <!-- MAIN NAVBAR (Client Side) -->
    <header id="main-header" class="sticky top-0 z-40 glass-header border-b border-slate-200 transition-all">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-20">
                <!-- Logo & Brand -->
                <a href="<?= base_url() ?>" class="flex items-center gap-3">
                    <?php if (!empty($site_logo)): ?>
                        <img src="<?= htmlspecialchars($site_logo) ?>" alt="<?= htmlspecialchars($site_title) ?>" class="w-10 h-10 rounded-xl object-contain shadow-md shadow-blue-500/10">
                    <?php else: ?>
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                            <i class="fa-solid fa-cubes text-xl"></i>
                        </div>
                    <?php endif; ?>
                    <div>
                        <span class="text-xl font-extrabold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent"><?= htmlspecialchars($site_title) ?></span>
                        <span class="text-[10px] block text-slate-400 font-semibold tracking-wider uppercase"><?= htmlspecialchars($site_tagline) ?></span>
                    </div>
                </a>

                <!-- Desktop Nav Navigation -->
                <nav class="hidden md:flex items-center gap-8 text-sm font-semibold text-slate-600">
                    <a href="#hero" class="hover:text-blue-600 transition-colors">Beranda</a>
                    <a href="#katalog" class="hover:text-blue-600 transition-colors">Katalog Aplikasi</a>
                    <a href="#fitur" class="hover:text-blue-600 transition-colors">Keunggulan</a>
                    <a href="#testimoni" class="hover:text-blue-600 transition-colors">Testimoni</a>
                    <a href="#faq" class="hover:text-blue-600 transition-colors">FAQ</a>
                    <a href="#kontak" class="hover:text-blue-600 transition-colors">Kontak</a>
                </nav>

                <!-- Actions Right -->
                <div class="hidden md:flex items-center gap-3">
                    <button onclick="openTrackModal()" class="flex items-center gap-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 px-3.5 py-2.5 rounded-xl transition-all border border-slate-200" title="Cek status tiket / pesanan Anda">
                        <i class="fa-solid fa-magnifying-glass-location text-blue-600"></i>
                        <span>Cek Pesanan</span>
                    </button>

                    <a href="#katalog" class="flex items-center gap-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-[1.02]">
                        <i class="fa-solid fa-rocket"></i>
                        <span>Cari Aplikasi</span>
                    </a>
                </div>

                <!-- Mobile Menu Button -->
                <div class="flex md:hidden items-center gap-2">
                    <button onclick="openTrackModal()" class="p-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm" title="Lacak Pesanan">
                        <i class="fa-solid fa-magnifying-glass-location text-blue-600"></i>
                    </button>
                    <button onclick="toggleMobileMenu()" class="p-2 text-slate-600 hover:bg-slate-100 rounded-lg">
                        <i class="fa-solid fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Mobile Menu Drawer -->
        <div id="mobile-menu" class="hidden md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-xl">
            <a href="#hero" onclick="toggleMobileMenu()" class="block py-2 font-medium text-slate-700 hover:text-blue-600">Beranda</a>
            <a href="#katalog" onclick="toggleMobileMenu()" class="block py-2 font-medium text-slate-700 hover:text-blue-600">Katalog Aplikasi</a>
            <a href="#fitur" onclick="toggleMobileMenu()" class="block py-2 font-medium text-slate-700 hover:text-blue-600">Keunggulan</a>
            <a href="#testimoni" onclick="toggleMobileMenu()" class="block py-2 font-medium text-slate-700 hover:text-blue-600">Testimoni</a>
            <a href="#faq" onclick="toggleMobileMenu()" class="block py-2 font-medium text-slate-700 hover:text-blue-600">Tanya Jawab (FAQ)</a>
            <a href="#kontak" onclick="toggleMobileMenu()" class="block py-2 font-medium text-slate-700 hover:text-blue-600">Kontak</a>
            <div class="pt-2 flex flex-col gap-2">
                <button onclick="toggleMobileMenu(); openTrackModal()" class="w-full text-center py-2.5 bg-slate-100 text-slate-700 font-semibold text-xs rounded-xl border border-slate-200">
                    <i class="fa-solid fa-magnifying-glass-location text-blue-600 mr-1"></i> Cek Status Pesanan
                </button>
                <a href="#katalog" onclick="toggleMobileMenu()" class="w-full text-center block text-xs font-semibold text-white bg-blue-600 py-3 rounded-xl shadow">
                    Cari Aplikasi Sekarang
                </a>
            </div>
        </div>
    </header>

    <!-- CLIENT SECTION MAIN CONTAINER -->
    <main id="client-view" class="flex-grow">
        <!-- Hero Section -->
        <section id="hero" class="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 bg-gradient-to-b from-blue-50/70 via-slate-50 to-slate-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div class="text-center max-w-3xl mx-auto">
                    <span class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 mb-6 border border-blue-200/80 shadow-sm">
                        <i class="fa-solid fa-sparkles text-blue-600"></i> <?= htmlspecialchars($hero_badge) ?>
                    </span>
                    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-tight">
                        <?= htmlspecialchars($hero_title) ?>
                    </h1>
                    <p class="mt-6 text-base sm:text-lg text-slate-600 leading-relaxed font-normal">
                        <?= htmlspecialchars($hero_subtitle) ?>
                    </p>
                    
                    <!-- Search Input Direct Hero -->
                    <div class="mt-10 max-w-xl mx-auto">
                        <div class="relative flex items-center">
                            <i class="fa-solid fa-magnifying-glass absolute left-4 text-slate-400 text-lg"></i>
                            <input type="text" id="hero-search-input" onkeyup="if(event.key==='Enter') executeHeroSearch()" placeholder="Cari aplikasi, misal: Kasir POS, HRIS, SIMRS, Toko..." class="w-full pl-12 pr-32 py-4 rounded-2xl border border-slate-300 bg-white shadow-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-700 text-sm">
                            <button onclick="executeHeroSearch()" class="absolute right-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs px-5 py-3 rounded-xl transition-all shadow-md">
                                Cari Aplikasi
                            </button>
                        </div>
                        <div class="mt-3 flex items-center justify-center gap-2 text-xs text-slate-500 flex-wrap">
                            <span>Populer:</span>
                            <button onclick="setCategoryFilter('POS & Kasir')" class="hover:underline text-blue-600 font-medium">POS Kasir</button> &bull; 
                            <button onclick="setCategoryFilter('ERP & HRIS')" class="hover:underline text-blue-600 font-medium">HRIS Gaji</button> &bull; 
                            <button onclick="setCategoryFilter('E-Commerce')" class="hover:underline text-blue-600 font-medium">Toko Online</button> &bull;
                            <button onclick="setCategoryFilter('Manajemen Rumah Sakit')" class="hover:underline text-blue-600 font-medium">SIMRS</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Background Decorative Blur -->
            <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[380px] bg-blue-400/15 blur-[120px] rounded-full pointer-events-none"></div>
        </section>

        <!-- Stats Counter Section -->
        <section class="border-y border-slate-200 bg-white py-8">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                    <div>
                        <p class="text-3xl font-extrabold text-blue-600" id="stat-apps-count"><?= count($apps) ?>+</p>
                        <p class="text-xs sm:text-sm text-slate-500 font-medium mt-1">Aplikasi Siap Pakai</p>
                    </div>
                    <div>
                        <p class="text-3xl font-extrabold text-indigo-600"><?= htmlspecialchars($settings['stat_uptime'] ?? '99.9%') ?></p>
                        <p class="text-xs sm:text-sm text-slate-500 font-medium mt-1">Garansi Uptime & Bug Free</p>
                    </div>
                    <div>
                        <p class="text-3xl font-extrabold text-blue-600"><?= htmlspecialchars($settings['stat_clients'] ?? '500+') ?></p>
                        <p class="text-xs sm:text-sm text-slate-500 font-medium mt-1">Klien Bisnis Terlayani</p>
                    </div>
                    <div>
                        <p class="text-3xl font-extrabold text-indigo-600"><?= htmlspecialchars($settings['stat_support'] ?? '24/7') ?></p>
                        <p class="text-xs sm:text-sm text-slate-500 font-medium mt-1">Dukungan Tim Teknis</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- CATALOG SECTION -->
        <section id="katalog" class="py-16 sm:py-24 bg-slate-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
                    <div>
                        <h2 class="text-3xl font-bold text-slate-900 tracking-tight">Katalog Solusi Aplikasi</h2>
                        <p class="text-slate-500 mt-2 text-sm">Pilih sistem digital yang telah teruji untuk mengoptimalkan efisiensi usaha Anda.</p>
                    </div>

                    <!-- Search Filter & Sort inside catalog -->
                    <div class="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
                        <div class="relative w-full sm:w-64">
                            <i class="fa-solid fa-search absolute left-3.5 top-3 text-slate-400 text-xs"></i>
                            <input type="text" id="catalog-search" onkeyup="renderCatalog()" placeholder="Filter nama atau fitur..." class="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm">
                        </div>

                        <select id="catalog-sort" onchange="renderCatalog()" class="w-full sm:w-auto px-3 py-2.5 rounded-xl border border-slate-200 bg-white text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm text-slate-700">
                            <option value="featured">Paling Populer / Unggulan</option>
                            <option value="price_asc">Harga: Termurah</option>
                            <option value="price_desc">Harga: Tertinggi</option>
                            <option value="title_asc">Nama: A - Z</option>
                        </select>
                    </div>
                </div>

                <!-- Category Filters Horizontal Pill -->
                <div class="flex items-center gap-2 overflow-x-auto pb-4 mb-8 custom-scrollbar" id="category-pills">
                    <!-- Dynamic Pills rendered via JS -->
                </div>

                <!-- Apps Grid -->
                <div id="apps-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <!-- Dynamic App Cards Rendered via JS -->
                </div>

                <!-- Empty State -->
                <div id="empty-state" class="hidden text-center py-16 bg-white rounded-3xl border border-dashed border-slate-300 mt-6">
                    <i class="fa-solid fa-box-open text-5xl text-slate-300 mb-4"></i>
                    <h3 class="text-lg font-semibold text-slate-700">Aplikasi Tidak Ditemukan</h3>
                    <p class="text-sm text-slate-500 mt-1">Coba gunakan kata kunci lain atau pilih kategori yang berbeda.</p>
                    <button onclick="resetFilters()" class="mt-4 px-4 py-2 bg-blue-50 text-blue-600 rounded-xl font-medium text-xs hover:bg-blue-100 transition-colors">
                        Reset Filter
                    </button>
                </div>
            </div>
        </section>

        <!-- FEATURES SECTION -->
        <section id="fitur" class="py-20 bg-white border-t border-slate-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center max-w-2xl mx-auto mb-16">
                    <h2 class="text-3xl font-bold text-slate-900">Mengapa Memilih MultiApps Solutions?</h2>
                    <p class="text-slate-500 mt-3 text-sm">Standar kode bersih, database SQLite mandiri dan cepat, serta tanpa biaya langganan server yang membebani.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div class="p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:border-blue-200 hover:shadow-xl transition-all group">
                        <div class="w-14 h-14 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center text-2xl mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                            <i class="fa-solid fa-server"></i>
                        </div>
                        <h3 class="text-xl font-bold text-slate-800 mb-2">Mudah Dipasang</h3>
                        <p class="text-slate-600 text-xs sm:text-sm leading-relaxed">Didukung database SQLite bawaan PHP PDO. Cukup upload ke File Manager cPanel Rumahweb tanpa perlu setting database MySQL yang rumit.</p>
                    </div>

                    <div class="p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:border-blue-200 hover:shadow-xl transition-all group">
                        <div class="w-14 h-14 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-2xl mb-6 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                            <i class="fa-solid fa-code"></i>
                        </div>
                        <h3 class="text-xl font-bold text-slate-800 mb-2">Full Source Code & Kustomisasi</h3>
                        <p class="text-slate-600 text-xs sm:text-sm leading-relaxed">Source code rapi, tanpa enkripsi. Tim developer kami siap membantu customisasi fitur tambahan sesuai spesifikasi alur kerja kantor Anda.</p>
                    </div>

                    <div class="p-8 rounded-3xl bg-slate-50 border border-slate-100 hover:border-blue-200 hover:shadow-xl transition-all group">
                        <div class="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-2xl mb-6 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                            <i class="fa-solid fa-headset"></i>
                        </div>
                        <h3 class="text-xl font-bold text-slate-800 mb-2">Garansi & Bantuan Purna Jual</h3>
                        <p class="text-slate-600 text-xs sm:text-sm leading-relaxed">Layanan pendampingan instalasi hingga sistem live, garansi perbaikan bug gratis, dan panduan penggunaan langsung ke WhatsApp tim teknis kami.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- TESTIMONIALS SECTION -->
        <section id="testimoni" class="py-20 bg-slate-900 text-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center max-w-2xl mx-auto mb-14">
                    <span class="text-blue-400 font-semibold text-xs tracking-wider uppercase">Ulasan Klien Nyata</span>
                    <h2 class="text-3xl font-bold mt-2">Dipercaya Berbagai Pemilik Bisnis</h2>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <?php foreach ($testimonials as $t): ?>
                        <div class="bg-slate-800/80 p-6 rounded-3xl border border-slate-700/50 flex flex-col justify-between">
                            <div>
                                <div class="text-amber-400 mb-3 text-xs">
                                    <?= str_repeat('<i class="fa-solid fa-star"></i>', (int)$t['rating']) ?>
                                </div>
                                <p class="text-slate-300 text-xs sm:text-sm italic mb-6 leading-relaxed">"<?= htmlspecialchars($t['review']) ?>"</p>
                            </div>
                            <div class="flex items-center gap-3 pt-4 border-t border-slate-700/60">
                                <div class="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold flex items-center justify-center text-xs shadow">
                                    <?= htmlspecialchars($t['avatar'] ?: substr($t['client_name'], 0, 2)) ?>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-sm text-white"><?= htmlspecialchars($t['client_name']) ?></h4>
                                    <span class="text-xs text-slate-400"><?= htmlspecialchars($t['client_role']) ?> <?= !empty($t['company']) ? '&bull; ' . htmlspecialchars($t['company']) : '' ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- FAQ ACCORDION SECTION -->
        <section id="faq" class="py-20 bg-slate-50 border-t border-slate-200">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-14">
                    <span class="text-blue-600 font-semibold text-xs tracking-wider uppercase">Tanya Jawab</span>
                    <h2 class="text-3xl font-bold text-slate-900 mt-2">Pertanyaan Yang Sering Diajukan</h2>
                    <p class="text-slate-500 text-xs sm:text-sm mt-2">Informasi penting seputar lisensi, instalasi hosting Rumahweb, dan garansi aplikasi.</p>
                </div>

                <div class="space-y-4">
                    <?php foreach ($faqs as $idx => $f): ?>
                        <div class="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm transition-all">
                            <button onclick="toggleFaq(<?= $idx ?>)" class="w-full py-4 px-6 text-left flex items-center justify-between gap-4 font-bold text-sm text-slate-800 hover:text-blue-600 transition-colors">
                                <span><?= htmlspecialchars($f['question']) ?></span>
                                <i id="faq-icon-<?= $idx ?>" class="fa-solid fa-chevron-down text-xs text-slate-400 transition-transform"></i>
                            </button>
                            <div id="faq-ans-<?= $idx ?>" class="hidden px-6 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                                <?= nl2br(htmlspecialchars($f['answer'])) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <!-- INQUIRY & CONTACT SECTION -->
        <section id="kontak" class="py-20 bg-white border-t border-slate-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 grid grid-cols-1 lg:grid-cols-2">
                    <!-- Left Info Column -->
                    <div class="p-8 sm:p-12 bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex flex-col justify-between">
                        <div>
                            <span class="inline-block px-3 py-1 bg-white/20 rounded-full text-xs font-semibold uppercase tracking-wider mb-4">Konsultasi & Pemesanan</span>
                            <h2 class="text-3xl font-extrabold mb-4">Diskusikan Kebutuhan Software Bisnis Anda</h2>
                            <p class="text-blue-100 text-xs sm:text-sm leading-relaxed mb-8">
                                Hubungi kami untuk konsultasi gratis, permintaan uji coba demo, atau negosiasi spesifikasi sistem custom untuk perusahaan Anda.
                            </p>
                            
                            <div class="space-y-5 text-xs sm:text-sm">
                                <div class="flex items-center gap-4">
                                    <div class="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center text-lg flex-shrink-0">
                                        <i class="fa-solid fa-envelope"></i>
                                    </div>
                                    <div>
                                        <span class="block text-[11px] text-blue-200">Email Resmi</span>
                                        <span class="font-semibold"><?= htmlspecialchars($contact_email) ?></span>
                                    </div>
                                </div>
                                <div class="flex items-center gap-4">
                                    <div class="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center text-lg flex-shrink-0">
                                        <i class="fa-brands fa-whatsapp text-emerald-300"></i>
                                    </div>
                                    <div>
                                        <span class="block text-[11px] text-blue-200">WhatsApp Resmi</span>
                                        <span class="font-semibold"><?= htmlspecialchars($contact_phone) ?></span>
                                    </div>
                                </div>
                                <div class="flex items-center gap-4">
                                    <div class="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center text-lg flex-shrink-0">
                                        <i class="fa-solid fa-location-dot"></i>
                                    </div>
                                    <div>
                                        <span class="block text-[11px] text-blue-200">Alamat Kantor / Studio</span>
                                        <span class="font-semibold"><?= htmlspecialchars($contact_address) ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-10 pt-6 border-t border-white/20 flex items-center justify-between text-sm">
                            <span class="text-xs text-blue-200">Terhubung di Media Sosial:</span>
                            <div class="flex gap-4 text-base">
                                <?php if (!empty($settings['facebook_url'])): ?><a href="<?= htmlspecialchars($settings['facebook_url']) ?>" target="_blank" class="hover:text-blue-200"><i class="fa-brands fa-facebook"></i></a><?php endif; ?>
                                <?php if (!empty($settings['instagram_url'])): ?><a href="<?= htmlspecialchars($settings['instagram_url']) ?>" target="_blank" class="hover:text-blue-200"><i class="fa-brands fa-instagram"></i></a><?php endif; ?>
                                <?php if (!empty($settings['linkedin_url'])): ?><a href="<?= htmlspecialchars($settings['linkedin_url']) ?>" target="_blank" class="hover:text-blue-200"><i class="fa-brands fa-linkedin"></i></a><?php endif; ?>
                                <?php if (!empty($settings['github_url'])): ?><a href="<?= htmlspecialchars($settings['github_url']) ?>" target="_blank" class="hover:text-blue-200"><i class="fa-brands fa-github"></i></a><?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Right Form Column -->
                    <div class="p-8 sm:p-12">
                        <h3 class="text-xl font-bold text-slate-800 mb-2">Kirim Formulir Permintaan / Pesanan</h3>
                        <p class="text-xs text-slate-500 mb-6">Data Anda tersimpan aman di database dan langsung terhubung dengan WhatsApp tim kami.</p>

                        <form id="public-inquiry-form" onsubmit="submitInquiryForm(event)" class="space-y-4 text-xs">
                            <div>
                                <label class="block font-semibold text-slate-700 mb-1">Nama Lengkap *</label>
                                <input type="text" id="inquiry-name" required placeholder="Contoh: Budi Pratama" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block font-semibold text-slate-700 mb-1">No. WhatsApp Aktif *</label>
                                    <input type="text" id="inquiry-phone" required placeholder="Contoh: 08123456789" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                </div>
                                <div>
                                    <label class="block font-semibold text-slate-700 mb-1">Email</label>
                                    <input type="email" id="inquiry-email" placeholder="budi@perusahaan.com" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label class="block font-semibold text-slate-700 mb-1">Aplikasi Yang Diminati</label>
                                    <select id="inquiry-app-select" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-slate-700">
                                        <option value="Konsultasi Sistem Custom / Umum">Konsultasi Sistem Custom / Umum</option>
                                        <?php foreach ($apps as $a): ?>
                                            <option value="<?= htmlspecialchars($a['title']) ?>"><?= htmlspecialchars($a['title']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div>
                                    <label class="block font-semibold text-slate-700 mb-1">Perusahaan / Nama Bisnis</label>
                                    <input type="text" id="inquiry-company" placeholder="PT Mitra Sejahtera / Cafe Kopi" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                </div>
                            </div>

                            <div>
                                <label class="block font-semibold text-slate-700 mb-1">Pesan / Spesifikasi Kebutuhan *</label>
                                <textarea id="inquiry-message" rows="3" required placeholder="Jelaskan kebutuhan sistem, jumlah pengguna, atau modul khusus yang Anda inginkan..." class="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none leading-relaxed"></textarea>
                            </div>

                            <button type="submit" id="inquiry-submit-btn" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-lg shadow-blue-600/30 transition-all text-sm flex items-center justify-center gap-2">
                                <i class="fa-solid fa-paper-plane"></i>
                                <span>Kirim Permintaan & Dapatkan Penawaran</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- FOOTER -->
    <footer class="bg-slate-900 text-slate-400 border-t border-slate-800 text-xs py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
                <div class="md:col-span-2">
                    <div class="flex items-center gap-3 mb-4">
                        <?php if (!empty($site_logo)): ?>
                            <img src="<?= htmlspecialchars($site_logo) ?>" alt="<?= htmlspecialchars($site_title) ?>" class="w-9 h-9 rounded-xl object-contain">
                        <?php else: ?>
                            <div class="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                                <i class="fa-solid fa-cubes text-sm"></i>
                            </div>
                        <?php endif; ?>
                        <span class="text-xl font-bold text-white"><?= htmlspecialchars($site_title) ?></span>
                    </div>
                    <p class="text-slate-400 max-w-md text-xs leading-relaxed">
                        Pusat direktori dan ekosistem solusi perangkat lunak terintegrasi untuk mendukung efisiensi operasional bisnis di berbagai industri digital Indonesia.
                    </p>
                    <p class="text-[11px] text-slate-500 mt-3">
                    </p>
                </div>
                <div>
                    <h4 class="text-white font-semibold mb-4 text-sm">Navigasi Halaman</h4>
                    <ul class="space-y-2 text-xs">
                        <li><a href="#hero" class="hover:text-white transition-colors">Beranda Utama</a></li>
                        <li><a href="#katalog" class="hover:text-white transition-colors">Semua Aplikasi</a></li>
                        <li><a href="#fitur" class="hover:text-white transition-colors">Keunggulan Solusi</a></li>
                        <li><a href="#faq" class="hover:text-white transition-colors">Tanya Jawab (FAQ)</a></li>
                        <li><a href="#kontak" class="hover:text-white transition-colors">Hubungi Kami</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-white font-semibold mb-4 text-sm">Layanan & Dukungan</h4>
                    <p class="text-xs text-slate-400 mb-3 leading-relaxed">Konsultasi solusi teknologi dan pembuatan sistem kustom untuk akselerasi bisnis Anda.</p>
                    <a href="<?= base_url('admin/login.php') ?>" class="inline-flex items-center gap-2 text-xs bg-slate-800 hover:bg-slate-700 text-white px-3.5 py-2 rounded-lg border border-slate-700 transition-colors">
                        <i class="fa-solid fa-lock text-blue-400"></i> Login Admin
                    </a>
                </div>
            </div>

            <div class="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
                <p>&copy; <?= date('Y') ?> <?= htmlspecialchars($site_title) ?>. All rights reserved.</p>
                <div class="flex gap-4">
                    <button onclick="openTrackModal()" class="hover:underline text-blue-400">Cek Status Tiket Pesanan</button>
                    <span>&bull;</span>
                    <a href="#hero" class="hover:underline">Kembali ke Atas</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- MODAL DETIL APLIKASI (CLIENT VIEW) -->
    <div id="app-detail-modal" class="fixed inset-0 z-50 hidden bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
        <div class="bg-white rounded-3xl shadow-2xl max-w-2xl w-full overflow-hidden transition-all transform border border-slate-100 my-8">
            <div class="relative h-48 sm:h-64 bg-slate-100">
                <img id="modal-app-img" src="" alt="App Preview" class="w-full h-full object-cover">
                <button onclick="closeAppModal()" class="absolute top-4 right-4 w-9 h-9 bg-black/40 hover:bg-black/60 text-white rounded-full flex items-center justify-center backdrop-blur-sm transition-colors">
                    <i class="fa-solid fa-xmark"></i>
                </button>
                <span id="modal-app-category" class="absolute bottom-4 left-4 bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full shadow">Category</span>
                <span id="modal-app-featured-badge" class="hidden absolute bottom-4 right-4 bg-amber-500 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider shadow">
                    <i class="fa-solid fa-star"></i> Unggulan
                </span>
            </div>

            <div class="p-6 sm:p-8">
                <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-2 mb-4">
                    <h3 id="modal-app-title" class="text-2xl font-bold text-slate-900">Nama Aplikasi</h3>
                    <div id="modal-app-price" class="text-xl font-extrabold text-blue-600">Rp 0</div>
                </div>

                <p id="modal-app-desc" class="text-slate-600 text-xs sm:text-sm leading-relaxed mb-6"></p>

                <!-- Key Specs / Features -->
                <div class="mb-6">
                    <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Fitur Utama & Keunggulan</h4>
                    <div id="modal-app-features" class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-medium text-slate-700">
                        <!-- Dynamic features list -->
                    </div>
                </div>

                <!-- Technical Specs Bar -->
                <div class="bg-slate-50 p-4 rounded-2xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-slate-500 mb-6">
                    <div><span class="block font-semibold text-slate-700">Platform</span> <span id="modal-app-platform">Web / Mobile</span></div>
                    <div><span class="block font-semibold text-slate-700">Versi</span> <span id="modal-app-version">v1.0.0</span></div>
                    <div><span class="block font-semibold text-slate-700">Lisensi</span> <span id="modal-app-license">Lifetime</span></div>
                    <div><span class="block font-semibold text-slate-700">Teknologi</span> <span id="modal-app-tech">PHP / SQLite</span></div>
                </div>

                <!-- Action Buttons -->
                <div class="flex flex-col sm:flex-row gap-3">
                    <button id="modal-demo-btn" onclick="" class="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-center text-xs sm:text-sm transition-colors flex items-center justify-center gap-2">
                        <i class="fa-solid fa-arrow-up-right-from-square"></i> Coba Demo Live
                    </button>
                    <button id="modal-order-btn" onclick="" class="flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-center text-xs sm:text-sm transition-colors shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2">
                        <i class="fa-solid fa-cart-shopping"></i> Pesan Aplikasi Ini
                    </button>
                    <button id="modal-wa-btn" onclick="" class="py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-center text-xs sm:text-sm transition-colors shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2" title="Tanya langsung di WhatsApp">
                        <i class="fa-brands fa-whatsapp text-lg"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>


    <!-- MODAL ORDER TRACKING (CEK STATUS PESANAN) -->
    <div id="track-modal" class="fixed inset-0 z-50 hidden bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
        <div class="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 sm:p-8 border border-slate-100 my-8">
            <div class="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-lg">
                        <i class="fa-solid fa-magnifying-glass-location"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-slate-800 text-base">Cek Status Pesanan / Tiket</h3>
                        <p class="text-xs text-slate-400">Pantau progres permintaan aplikasi Anda</p>
                    </div>
                </div>
                <button onclick="closeTrackModal()" class="text-slate-400 hover:text-slate-600">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <form onsubmit="executeTracking(event)" class="space-y-4">
                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1.5">No. WhatsApp atau Kode Tiket (INQ-...)</label>
                    <div class="flex gap-2">
                        <input type="text" id="track-input" required placeholder="Contoh: 08123456789 atau INQ-20261107-..." class="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none">
                        <button type="submit" class="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-xs transition-colors">
                            Lacak
                        </button>
                    </div>
                </div>
            </form>

            <div id="track-results" class="mt-6 space-y-3">
                <!-- Result cards dynamically rendered here -->
            </div>
        </div>
    </div>


    <!-- MODAL SUCCESS INQUIRY (HASIL PEMESANAN & LINK WHATSAPP) -->
    <div id="inquiry-success-modal" class="fixed inset-0 z-50 hidden bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6 sm:p-8 border border-slate-100 text-center">
            <div class="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-2xl mx-auto mb-4">
                <i class="fa-solid fa-circle-check"></i>
            </div>

            <h3 class="text-xl font-bold text-slate-800 mb-2">Permintaan Berhasil Dikirim!</h3>
            <p class="text-xs text-slate-500 mb-4">
                Terima kasih, data Anda telah tersimpan di database kami dengan nomor tiket:
            </p>

            <div class="p-3 bg-slate-50 rounded-2xl border border-slate-200 mb-6 font-mono text-sm font-bold text-blue-600" id="success-invoice-code">
                INQ-XXXX
            </div>

            <div class="space-y-3">
                <a id="success-wa-link" href="#" target="_blank" class="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all">
                    <i class="fa-brands fa-whatsapp text-lg"></i>
                    <span>Lanjut Chat di WhatsApp Sekarang</span>
                </a>

                <button onclick="closeSuccessModal()" class="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors">
                    Tutup
                </button>
            </div>
        </div>
    </div>


    <!-- FLOATING WHATSAPP CHAT BUTTON -->
    <a href="<?= generate_wa_url($contact_whatsapp, $whatsapp_greeting) ?>" target="_blank" class="fixed bottom-6 left-6 z-40 bg-emerald-500 hover:bg-emerald-600 text-white p-4 rounded-full shadow-2xl shadow-emerald-500/40 hover:scale-110 transition-all flex items-center justify-center group" title="Chat WhatsApp Sekarang">
        <i class="fa-brands fa-whatsapp text-2xl"></i>
        <span class="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs transition-all duration-300 ease-in-out px-0 group-hover:px-2 text-xs font-bold">Chat WhatsApp</span>
    </a>


    <!-- CLIENT SIDE JAVASCRIPT LOGIC -->
    <script>
        // Data injected from SQLite PHP
        const RAW_APPS = <?= json_encode($apps_json_data, JSON_UNESCAPED_UNICODE) ?>;
        const CATEGORIES = <?= json_encode(array_merge(['Semua'], array_column($categories, 'name')), JSON_UNESCAPED_UNICODE) ?>;
        const WA_PHONE = "<?= htmlspecialchars($contact_whatsapp) ?>";
        const WA_GREETING = "<?= htmlspecialchars($whatsapp_greeting) ?>";

        let activeCategory = "Semua";

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            renderCategoryPills();
            renderCatalog();
        });

        // Category Pills
        function renderCategoryPills() {
            const container = document.getElementById('category-pills');
            container.innerHTML = '';

            CATEGORIES.forEach(cat => {
                const isActive = cat === activeCategory;
                const btn = document.createElement('button');
                btn.onclick = () => setCategoryFilter(cat);
                btn.className = `px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    isActive 
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30' 
                        : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`;
                btn.innerText = cat;
                container.appendChild(btn);
            });
        }

        function setCategoryFilter(cat) {
            activeCategory = cat;
            renderCategoryPills();
            renderCatalog();
        }

        // Render Catalog Grid
        function renderCatalog() {
            const grid = document.getElementById('apps-grid');
            const emptyState = document.getElementById('empty-state');
            const searchQuery = (document.getElementById('catalog-search').value || '').toLowerCase().trim();
            const sortBy = document.getElementById('catalog-sort').value;

            grid.innerHTML = '';

            let filtered = RAW_APPS.filter(app => {
                const matchCategory = (activeCategory === "Semua") || (app.category === activeCategory);
                const matchSearch = app.title.toLowerCase().includes(searchQuery) || 
                                    app.description.toLowerCase().includes(searchQuery) ||
                                    (app.features || []).some(f => f.toLowerCase().includes(searchQuery));
                return matchCategory && matchSearch;
            });

            // Sorting
            if (sortBy === 'price_asc') {
                filtered.sort((a, b) => a.price - b.price);
            } else if (sortBy === 'price_desc') {
                filtered.sort((a, b) => b.price - a.price);
            } else if (sortBy === 'title_asc') {
                filtered.sort((a, b) => a.title.localeCompare(b.title));
            } else {
                // Featured first
                filtered.sort((a, b) => (b.is_featured ? 1 : 0) - (a.is_featured ? 1 : 0));
            }

            if (filtered.length === 0) {
                emptyState.classList.remove('hidden');
            } else {
                emptyState.classList.add('hidden');

                filtered.forEach(app => {
                    const card = document.createElement('div');
                    card.className = "bg-white rounded-3xl overflow-hidden border border-slate-200 hover:shadow-2xl transition-all flex flex-col justify-between group";

                    card.innerHTML = `
                        <div>
                            <div class="relative h-48 overflow-hidden bg-slate-100">
                                <img src="${app.image}" onerror="this.src='https://placehold.co/600x400/0284c7/white?text=App'" alt="${app.title}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300">
                                <span class="absolute top-3 left-3 bg-white/90 backdrop-blur-sm text-slate-800 text-[11px] font-bold px-3 py-1 rounded-full border border-slate-200">
                                    ${app.category}
                                </span>
                                ${app.is_featured ? '<span class="absolute top-3 right-3 bg-amber-500 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider shadow"><i class="fa-solid fa-star"></i> Unggulan</span>' : ''}
                            </div>
                            <div class="p-6">
                                <h3 class="text-lg font-bold text-slate-800 group-hover:text-blue-600 transition-colors line-clamp-1">${app.title}</h3>
                                <p class="text-slate-500 text-xs mt-2 line-clamp-2 leading-relaxed">${app.description}</p>
                                
                                <div class="mt-4 pt-4 border-t border-slate-100 flex flex-wrap gap-1.5">
                                    ${(app.features || []).slice(0, 3).map(f => `<span class="bg-slate-100 text-slate-600 text-[10px] font-medium px-2 py-0.5 rounded-md flex items-center gap-1"><i class="fa-solid fa-check text-blue-500 text-[9px]"></i>${f}</span>`).join('')}
                                </div>
                            </div>
                        </div>

                        <div class="px-6 pb-6 pt-2 flex items-center justify-between border-t border-slate-50">
                            <div>
                                <span class="block text-[10px] text-slate-400 font-semibold uppercase">${app.price_label}</span>
                                <span class="text-base font-extrabold text-blue-600">${app.price_formatted}</span>
                            </div>
                            <button onclick="openAppModal(${app.id})" class="bg-blue-50 hover:bg-blue-600 text-blue-600 hover:text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5">
                                Detail <i class="fa-solid fa-arrow-right text-[10px]"></i>
                            </button>
                        </div>
                    `;
                    grid.appendChild(card);
                });
            }
        }

        function resetFilters() {
            activeCategory = "Semua";
            document.getElementById('catalog-search').value = '';
            document.getElementById('catalog-sort').value = 'featured';
            renderCategoryPills();
            renderCatalog();
        }

        function executeHeroSearch() {
            const query = document.getElementById('hero-search-input').value;
            document.getElementById('catalog-search').value = query;
            renderCatalog();
            document.getElementById('katalog').scrollIntoView({ behavior: 'smooth' });
        }

        // Detail Modal
        function openAppModal(appId) {
            const app = RAW_APPS.find(a => a.id == appId);
            if (!app) return;

            document.getElementById('modal-app-img').src = app.image;
            document.getElementById('modal-app-category').innerText = app.category;
            
            const featBadge = document.getElementById('modal-app-featured-badge');
            if (app.is_featured) featBadge.classList.remove('hidden');
            else featBadge.classList.add('hidden');

            document.getElementById('modal-app-title').innerText = app.title;
            document.getElementById('modal-app-price').innerText = app.price_formatted;
            document.getElementById('modal-app-desc').innerText = app.full_description || app.description;
            document.getElementById('modal-app-platform').innerText = app.platform;
            document.getElementById('modal-app-version').innerText = app.version;
            document.getElementById('modal-app-license').innerText = app.license;
            document.getElementById('modal-app-tech').innerText = app.tech_stack;

            // Features list
            const featContainer = document.getElementById('modal-app-features');
            featContainer.innerHTML = '';
            (app.features || []).forEach(f => {
                const div = document.createElement('div');
                div.className = "flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-100";
                div.innerHTML = `<i class="fa-solid fa-circle-check text-blue-600 text-xs"></i> <span>${f}</span>`;
                featContainer.appendChild(div);
            });

            // Demo Button
            const demoBtn = document.getElementById('modal-demo-btn');
            if (app.demo_url) {
                demoBtn.style.display = 'flex';
                demoBtn.onclick = () => window.open(app.demo_url, '_blank');
            } else {
                demoBtn.style.display = 'none';
            }

            // Order Button
            const orderBtn = document.getElementById('modal-order-btn');
            orderBtn.onclick = () => {
                closeAppModal();
                document.getElementById('inquiry-app-select').value = app.title;
                document.getElementById('kontak').scrollIntoView({ behavior: 'smooth' });
            };

            // WhatsApp Direct Button
            const waBtn = document.getElementById('modal-wa-btn');
            const waText = encodeURIComponent(`${WA_GREETING}${app.title} (Harga: ${app.price_formatted})`);
            waBtn.onclick = () => window.open(`https://wa.me/${WA_PHONE}?text=${waText}`, '_blank');

            document.getElementById('app-detail-modal').classList.remove('hidden');
        }

        function closeAppModal() {
            document.getElementById('app-detail-modal').classList.add('hidden');
        }

        // FAQ Toggle
        function toggleFaq(index) {
            const ans = document.getElementById(`faq-ans-${index}`);
            const icon = document.getElementById(`faq-icon-${index}`);
            ans.classList.toggle('hidden');
            icon.classList.toggle('rotate-180');
        }

        // Mobile Menu Toggle
        function toggleMobileMenu() {
            const menu = document.getElementById('mobile-menu');
            menu.classList.toggle('hidden');
        }

        // Submit Inquiry Form via AJAX
        function submitInquiryForm(e) {
            e.preventDefault();
            const btn = document.getElementById('inquiry-submit-btn');
            btn.disabled = true;
            btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> <span>Mengirim Data...</span>`;

            const payload = {
                name: document.getElementById('inquiry-name').value,
                phone: document.getElementById('inquiry-phone').value,
                email: document.getElementById('inquiry-email').value,
                company: document.getElementById('inquiry-company').value,
                app_name: document.getElementById('inquiry-app-select').value,
                message: document.getElementById('inquiry-message').value
            };

            fetch('<?= base_url("api/inquiry.php") ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(data => {
                btn.disabled = false;
                btn.innerHTML = `<i class="fa-solid fa-paper-plane"></i> <span>Kirim Permintaan & Dapatkan Penawaran</span>`;

                if (data.success) {
                    document.getElementById('public-inquiry-form').reset();
                    document.getElementById('success-invoice-code').innerText = data.invoice_code;
                    document.getElementById('success-wa-link').href = data.whatsapp_url;
                    document.getElementById('inquiry-success-modal').classList.remove('hidden');
                } else {
                    showToast(data.message || 'Gagal mengirim permintaan.', 'error');
                }
            })
            .catch(err => {
                btn.disabled = false;
                btn.innerHTML = `<i class="fa-solid fa-paper-plane"></i> <span>Kirim Permintaan & Dapatkan Penawaran</span>`;
                showToast('Terjadi kesalahan jaringan saat mengirim permintaan.', 'error');
            });
        }

        function closeSuccessModal() {
            document.getElementById('inquiry-success-modal').classList.add('hidden');
        }

        // Tracking Order Modal
        function openTrackModal() {
            document.getElementById('track-modal').classList.remove('hidden');
        }

        function closeTrackModal() {
            document.getElementById('track-modal').classList.add('hidden');
        }

        function executeTracking(e) {
            e.preventDefault();
            const query = document.getElementById('track-input').value.trim();
            const resultsContainer = document.getElementById('track-results');
            resultsContainer.innerHTML = '<div class="text-center py-4 text-xs text-slate-400"><i class="fa-solid fa-spinner fa-spin mr-1"></i> Memeriksa status pesanan...</div>';

            fetch(`<?= base_url("api/track.php") ?>?query=${encodeURIComponent(query)}`)
            .then(res => res.json())
            .then(res => {
                resultsContainer.innerHTML = '';
                if (res.success && res.data) {
                    res.data.forEach(item => {
                        const card = document.createElement('div');
                        card.className = "p-4 rounded-2xl border border-slate-200 bg-slate-50 text-xs space-y-2";
                        
                        let badgeColor = "bg-slate-200 text-slate-700";
                        if (item.status === 'Baru') badgeColor = "bg-amber-100 text-amber-800 font-bold";
                        else if (item.status === 'Diproses') badgeColor = "bg-blue-100 text-blue-800 font-bold";
                        else if (item.status === 'Selesai') badgeColor = "bg-emerald-100 text-emerald-800 font-bold";
                        else if (item.status === 'Dibatalkan') badgeColor = "bg-red-100 text-red-800";

                        card.innerHTML = `
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="font-bold text-slate-800 block">${item.app_name}</span>
                                    <span class="text-[10px] text-slate-400 font-mono">${item.invoice_code} &bull; ${item.date}</span>
                                </div>
                                <span class="px-2.5 py-0.5 rounded-full text-[10px] ${badgeColor}">
                                    ${item.status}
                                </span>
                            </div>
                            <div class="p-2.5 bg-white rounded-xl border border-slate-200 text-slate-600 text-[11px] leading-relaxed">
                                <span class="font-semibold text-slate-700 block mb-0.5"><i class="fa-solid fa-circle-info text-blue-500 mr-1"></i>Keterangan Tim:</span>
                                ${item.admin_notes}
                            </div>
                        `;
                        resultsContainer.appendChild(card);
                    });
                } else {
                    resultsContainer.innerHTML = `
                        <div class="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs">
                            <i class="fa-solid fa-circle-exclamation mr-1"></i> ${res.message}
                        </div>
                    `;
                }
            })
            .catch(() => {
                resultsContainer.innerHTML = `
                    <div class="p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs">
                        Gagal menghubungi server pelacakan.
                    </div>
                `;
            });
        }

        // Toast Helper
        function showToast(message, type = 'info') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            const bgClass = type === 'success' ? 'bg-emerald-600' : (type === 'error' ? 'bg-red-600' : 'bg-slate-800');
            
            toast.className = `${bgClass} text-white px-4 py-3 rounded-xl shadow-xl text-xs font-semibold flex items-center gap-2 pointer-events-auto transition-all transform translate-y-2 opacity-0`;
            toast.innerHTML = `<i class="fa-solid ${type === 'success' ? 'fa-circle-check' : 'fa-circle-info'}"></i><span>${message}</span>`;

            container.appendChild(toast);
            setTimeout(() => toast.classList.remove('translate-y-2', 'opacity-0'), 10);
            setTimeout(() => {
                toast.classList.add('opacity-0', 'translate-y-2');
                setTimeout(() => toast.remove(), 300);
            }, 4000);
        }
    </script>
</body>
</html>
