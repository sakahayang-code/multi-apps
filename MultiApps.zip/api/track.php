<?php
/**
 * MultiApps Solutions - API Endpoint: Track Inquiry / Order Status
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/config.php';

$query = clean_input($_GET['query'] ?? $_POST['query'] ?? '');

if (empty($query)) {
    echo json_encode(['success' => false, 'message' => 'Silakan masukkan nomor telepon atau kode tiket pesanan Anda.']);
    exit;
}

try {
    $pdo = get_db();

    // Clean query if it looks like phone
    $phone_digits = preg_replace('/[^0-9]/', '', $query);

    $sql = "SELECT invoice_code, app_name, customer_name, status, admin_notes, created_at, updated_at 
            FROM inquiries 
            WHERE invoice_code = :code ";
    
    $params = [':code' => strtoupper($query)];

    if (strlen($phone_digits) >= 8) {
        $sql .= " OR customer_phone LIKE :phone ";
        $params[':phone'] = '%' . $phone_digits . '%';
    }

    $sql .= " ORDER BY created_at DESC LIMIT 5";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll();

    if (empty($results)) {
        echo json_encode([
            'success' => false, 
            'message' => 'Pesanan atau tiket tidak ditemukan. Pastikan nomor WhatsApp atau Kode Tiket (INQ-...) yang dimasukkan sudah sesuai.'
        ]);
        exit;
    }

    // Format output
    $formatted = [];
    foreach ($results as $item) {
        $formatted[] = [
            'invoice_code' => $item['invoice_code'],
            'app_name' => $item['app_name'],
            'customer_name' => $item['customer_name'],
            'status' => $item['status'],
            'admin_notes' => !empty($item['admin_notes']) ? $item['admin_notes'] : 'Permintaan Anda sedang dalam antrean tim konsultan kami.',
            'date' => date('d M Y, H:i', strtotime($item['created_at']))
        ];
    }

    echo json_encode([
        'success' => true,
        'data' => $formatted
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Gagal mengambil data pelacakan: ' . $e->getMessage()
    ]);
}
