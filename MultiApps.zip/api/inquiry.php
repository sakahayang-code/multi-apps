<?php
/**
 * MultiApps Solutions - API Endpoint: Submit Inquiry / Order
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Metode HTTP tidak didukung.']);
    exit;
}

// Read inputs (supports form-data and application/json)
$input_raw = file_get_contents('php://input');
$json_data = json_decode($input_raw, true);

$name = clean_input($_POST['name'] ?? $json_data['name'] ?? '');
$phone = clean_input($_POST['phone'] ?? $json_data['phone'] ?? '');
$email = clean_input($_POST['email'] ?? $json_data['email'] ?? '');
$company = clean_input($_POST['company'] ?? $json_data['company'] ?? '');
$app_id = isset($_POST['app_id']) ? (int)$_POST['app_id'] : (isset($json_data['app_id']) ? (int)$json_data['app_id'] : null);
$app_name = clean_input($_POST['app_name'] ?? $json_data['app_name'] ?? 'Konsultasi Umum');
$message = clean_input($_POST['message'] ?? $json_data['message'] ?? '');
$budget = clean_input($_POST['budget'] ?? $json_data['budget'] ?? '');

// Validation
if (empty($name)) {
    echo json_encode(['success' => false, 'message' => 'Nama lengkap wajib diisi.']);
    exit;
}

if (empty($phone)) {
    echo json_encode(['success' => false, 'message' => 'Nomor WhatsApp / telepon wajib diisi.']);
    exit;
}

if (empty($message)) {
    echo json_encode(['success' => false, 'message' => 'Pesan / spesifikasi kebutuhan wajib diisi.']);
    exit;
}

try {
    $pdo = get_db();

    // Generate unique invoice code
    $invoice_code = 'INQ-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -4));

    $stmt = $pdo->prepare("INSERT INTO inquiries (
        invoice_code, app_id, app_name, customer_name, customer_phone, customer_email, company, message, budget, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Baru')");

    $stmt->execute([
        $invoice_code,
        $app_id,
        $app_name,
        $name,
        $phone,
        $email,
        $company,
        $message,
        $budget
    ]);

    // Prepare WhatsApp URL for direct chat with store admin
    $owner_wa = get_setting('contact_whatsapp', '6281234567890');
    $greeting = get_setting('whatsapp_greeting', 'Halo MultiApps Solutions, saya ingin konsultasi mengenai aplikasi: ');
    
    $wa_text = "Halo MultiApps Solutions,\n";
    $wa_text .= "Saya telah mengajukan pesanan/konsultasi melalui website.\n\n";
    $wa_text .= "*No. Tiket:* {$invoice_code}\n";
    $wa_text .= "*Nama:* {$name}\n";
    if (!empty($company)) {
        $wa_text .= "*Perusahaan:* {$company}\n";
    }
    $wa_text .= "*Aplikasi:* {$app_name}\n";
    if (!empty($budget)) {
        $wa_text .= "*Estimasi Budget:* {$budget}\n";
    }
    $wa_text .= "*Pesan/Kebutuhan:* {$message}\n\n";
    $wa_text .= "Mohon info tindak lanjut dan penawarannya. Terima kasih.";

    $wa_url = generate_wa_url($owner_wa, $wa_text);

    echo json_encode([
        'success' => true,
        'message' => 'Permintaan Anda berhasil dikirim ke database kami! Tim kami akan segera menindaklanjuti.',
        'invoice_code' => $invoice_code,
        'customer_name' => $name,
        'app_name' => $app_name,
        'whatsapp_url' => $wa_url
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Terjadi kesalahan sistem saat menyimpan permintaan: ' . $e->getMessage()
    ]);
}
