<?php
/**
 * MultiApps Solutions - Admin Apps Management (CRUD)
 */

$page_title = 'Manajemen Aplikasi';
$page_subtitle = 'Kelola portofolio software, harga, fitur, dan status katalog';

require_once __DIR__ . '/layout/header.php';

$pdo = get_db();
$action = $_GET['action'] ?? 'list';
$error = '';

// Handle Image Upload Helper
function handle_image_upload($file) {
    if (empty($file['name']) || $file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    $allowed_types = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $allowed_exts = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime, $allowed_types) || !in_array($ext, $allowed_exts)) {
        throw new Exception('Format gambar tidak didukung. Harap unggah JPG, PNG, atau WebP.');
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        throw new Exception('Ukuran gambar terlalu besar (maksimal 5MB).');
    }

    $upload_dir = __DIR__ . '/../uploads/apps/';
    if (!file_exists($upload_dir)) {
        @mkdir($upload_dir, 0755, true);
    }

    $filename = 'app_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $target = $upload_dir . $filename;

    if (move_uploaded_file($file['tmp_name'], $target)) {
        return 'uploads/apps/' . $filename;
    }

    throw new Exception('Gagal menyimpan file gambar ke server.');
}

// -------------------------------------------------------------------------
// POST ACTIONS (Save, Update, Delete, Toggle)
// -------------------------------------------------------------------------

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $post_action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('error', 'Token keamanan CSRF tidak valid. Silakan coba lagi.');
        header('Location: ' . base_url('admin/apps.php'));
        exit;
    }

    // Toggle Featured
    if ($post_action === 'toggle_featured') {
        $id = (int)$_POST['id'];
        $pdo->prepare("UPDATE apps SET is_featured = CASE WHEN is_featured = 1 THEN 0 ELSE 1 END WHERE id = ?")->execute([$id]);
        set_flash('success', 'Status unggulan aplikasi berhasil diperbarui.');
        header('Location: ' . base_url('admin/apps.php'));
        exit;
    }

    // Toggle Active
    if ($post_action === 'toggle_active') {
        $id = (int)$_POST['id'];
        $pdo->prepare("UPDATE apps SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?")->execute([$id]);
        set_flash('success', 'Status aktif aplikasi berhasil diperbarui.');
        header('Location: ' . base_url('admin/apps.php'));
        exit;
    }

    // Delete App
    if ($post_action === 'delete') {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM apps WHERE id = ?")->execute([$id]);
        set_flash('info', 'Aplikasi berhasil dihapus dari katalog.');
        header('Location: ' . base_url('admin/apps.php'));
        exit;
    }

    // Duplicate App
    if ($post_action === 'duplicate') {
        $id = (int)$_POST['id'];
        $orig = $pdo->prepare("SELECT * FROM apps WHERE id = ?");
        $orig->execute([$id]);
        $app = $orig->fetch();
        if ($app) {
            $new_title = $app['title'] . ' (Salinan)';
            $new_slug = slugify($new_title) . '-' . time();
            $stmt = $pdo->prepare("INSERT INTO apps (title, slug, category_id, price, price_label, image, description, full_description, features, tech_stack, platform, version, license, demo_url, is_featured, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $new_title, $new_slug, $app['category_id'], $app['price'], $app['price_label'],
                $app['image'], $app['description'], $app['full_description'], $app['features'],
                $app['tech_stack'], $app['platform'], $app['version'], $app['license'], $app['demo_url'],
                0, 1
            ]);
            set_flash('success', 'Aplikasi berhasil diduplikasi.');
        }
        header('Location: ' . base_url('admin/apps.php'));
        exit;
    }

    // Create or Update
    if ($post_action === 'save') {
        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $title = clean_input($_POST['title'] ?? '');
        $category_id = (int)($_POST['category_id'] ?? 0);
        $price = (float)($_POST['price'] ?? 0);
        $price_label = clean_input($_POST['price_label'] ?? 'Mulai dari');
        $image_url = clean_input($_POST['image_url'] ?? '');
        $description = clean_input($_POST['description'] ?? '');
        $full_description = clean_input($_POST['full_description'] ?? '');
        $features = trim($_POST['features'] ?? '');
        $tech_stack = clean_input($_POST['tech_stack'] ?? '');
        $platform = clean_input($_POST['platform'] ?? 'Web');
        $version = clean_input($_POST['version'] ?? 'v1.0.0');
        $license = clean_input($_POST['license'] ?? 'Lisensi Seumur Hidup');
        $demo_url = clean_input($_POST['demo_url'] ?? '');
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        if (empty($title)) {
            $error = 'Nama aplikasi wajib diisi.';
        } elseif ($category_id <= 0) {
            $error = 'Silakan pilih kategori yang valid.';
        } else {
            // Slug
            $slug = !empty($_POST['slug']) ? slugify($_POST['slug']) : slugify($title);

            // Handle image upload if provided
            $final_image = $image_url;
            if (!empty($_FILES['image_file']['name'])) {
                try {
                    $uploaded = handle_image_upload($_FILES['image_file']);
                    if ($uploaded) {
                        $final_image = $uploaded;
                    }
                } catch (Exception $e) {
                    $error = $e->getMessage();
                }
            }

            if (empty($error)) {
                if ($id) {
                    // Update
                    $stmt = $pdo->prepare("UPDATE apps SET 
                        title = ?, slug = ?, category_id = ?, price = ?, price_label = ?, image = ?,
                        description = ?, full_description = ?, features = ?, tech_stack = ?,
                        platform = ?, version = ?, license = ?, demo_url = ?, is_featured = ?, is_active = ?,
                        updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?");
                    $stmt->execute([
                        $title, $slug, $category_id, $price, $price_label, $final_image,
                        $description, $full_description, $features, $tech_stack,
                        $platform, $version, $license, $demo_url, $is_featured, $is_active,
                        $id
                    ]);
                    set_flash('success', "Aplikasi '{$title}' berhasil diperbarui.");
                } else {
                    // Check duplicate slug
                    $check = $pdo->prepare("SELECT id FROM apps WHERE slug = ?");
                    $check->execute([$slug]);
                    if ($check->fetch()) {
                        $slug .= '-' . time();
                    }

                    // Create
                    $stmt = $pdo->prepare("INSERT INTO apps (
                        title, slug, category_id, price, price_label, image, description,
                        full_description, features, tech_stack, platform, version, license,
                        demo_url, is_featured, is_active
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $title, $slug, $category_id, $price, $price_label, $final_image,
                        $description, $full_description, $features, $tech_stack,
                        $platform, $version, $license, $demo_url, $is_featured, $is_active
                    ]);
                    set_flash('success', "Aplikasi baru '{$title}' berhasil ditambahkan ke katalog!");
                }
                header('Location: ' . base_url('admin/apps.php'));
                exit;
            }
        }
    }
}

// Fetch all categories for dropdown
$categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order ASC, name ASC")->fetchAll();

// -------------------------------------------------------------------------
// VIEW: CREATE / EDIT FORM
// -------------------------------------------------------------------------

if ($action === 'create' || $action === 'edit'):
    $edit_id = isset($_GET['id']) ? (int)$_GET['id'] : null;
    $app_data = [
        'id' => '',
        'title' => '',
        'slug' => '',
        'category_id' => '',
        'price' => '1500000',
        'price_label' => 'Mulai dari',
        'image' => '',
        'description' => '',
        'full_description' => '',
        'features' => "Cetak Struk Thermal\nLaporan Penjualan Otomatis\nMulti-Pengguna & Hak Akses",
        'tech_stack' => 'PHP 8, Tailwind CSS, SQLite',
        'platform' => 'Web Responsive',
        'version' => 'v1.0.0',
        'license' => 'Lisensi Seumur Hidup',
        'demo_url' => '',
        'is_featured' => 0,
        'is_active' => 1
    ];

    if ($action === 'edit' && $edit_id) {
        $stmt = $pdo->prepare("SELECT * FROM apps WHERE id = ?");
        $stmt->execute([$edit_id]);
        $fetched = $stmt->fetch();
        if ($fetched) {
            $app_data = $fetched;
        } else {
            set_flash('error', 'Aplikasi tidak ditemukan.');
            header('Location: ' . base_url('admin/apps.php'));
            exit;
        }
    }
?>

    <div class="max-w-4xl mx-auto">
        <div class="mb-6 flex items-center justify-between">
            <div>
                <a href="<?= base_url('admin/apps.php') ?>" class="text-xs text-blue-600 font-semibold hover:underline flex items-center gap-1.5 mb-1">
                    <i class="fa-solid fa-arrow-left"></i> Kembali ke Daftar Aplikasi
                </a>
                <h2 class="text-xl font-bold text-slate-800"><?= $action === 'edit' ? 'Edit Aplikasi: ' . htmlspecialchars($app_data['title']) : 'Tambah Aplikasi Baru' ?></h2>
            </div>
        </div>

        <?php if (!empty($error)): ?>
            <div class="mb-5 p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-3 text-xs text-red-700">
                <i class="fa-solid fa-triangle-exclamation text-base"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('admin/apps.php') ?>" method="POST" enctype="multipart/form-data" class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm space-y-6 text-xs">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= htmlspecialchars($app_data['id']) ?>">

            <!-- Section 1: Basic Info -->
            <div>
                <h4 class="font-bold text-slate-800 text-sm mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
                    <i class="fa-solid fa-circle-info text-blue-600"></i> Informasi Utama
                </h4>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="sm:col-span-2">
                        <label class="block font-semibold text-slate-700 mb-1.5">Nama Aplikasi / Sistem *</label>
                        <input type="text" name="title" required value="<?= htmlspecialchars($app_data['title']) ?>" placeholder="Contoh: Smart POS Resto Pro" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Kategori *</label>
                        <select name="category_id" required class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white">
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= $app_data['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">URL Slug (Opsional)</label>
                        <input type="text" name="slug" value="<?= htmlspecialchars($app_data['slug']) ?>" placeholder="Otomatis dari nama aplikasi jika kosong" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono text-slate-600">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Harga Aplikasi (Angka/Rp) *</label>
                        <input type="number" name="price" required value="<?= htmlspecialchars($app_data['price']) ?>" placeholder="1500000" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-semibold text-blue-600">
                        <span class="text-[10px] text-slate-400">Isi 0 jika harga disepakati via konsultasi ("Hubungi Kami").</span>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Label Harga</label>
                        <input type="text" name="price_label" value="<?= htmlspecialchars($app_data['price_label']) ?>" placeholder="Mulai dari / Sekali Beli / SaaS" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                </div>
            </div>

            <!-- Section 2: Media & Image -->
            <div>
                <h4 class="font-bold text-slate-800 text-sm mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
                    <i class="fa-solid fa-image text-indigo-600"></i> Gambar / Screenshot Aplikasi
                </h4>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">URL Gambar Eksternal (Unsplash / Link Langsung)</label>
                        <input type="url" name="image_url" id="image-url-input" value="<?= htmlspecialchars(strpos($app_data['image'], 'http') === 0 ? $app_data['image'] : '') ?>" placeholder="https://images.unsplash.com/..." class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Atau Unggah Gambar dari Komputer</label>
                        <input type="file" name="image_file" accept="image/*" class="w-full px-3 py-2 rounded-xl border border-slate-300 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                        <span class="text-[10px] text-slate-400">Mendukung format JPG, PNG, WebP (maks 5MB).</span>
                    </div>

                    <?php if (!empty($app_data['image'])): ?>
                        <div class="sm:col-span-2 flex items-center gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                            <?php 
                            $img_src = strpos($app_data['image'], 'http') === 0 ? $app_data['image'] : base_url($app_data['image']);
                            ?>
                            <img src="<?= htmlspecialchars($img_src) ?>" alt="Preview" class="w-16 h-12 object-cover rounded-lg border border-slate-300">
                            <div>
                                <span class="font-semibold text-slate-700 block">Gambar Saat Ini:</span>
                                <span class="text-[10px] text-slate-500 truncate block max-w-md"><?= htmlspecialchars($app_data['image']) ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Section 3: Descriptions & Features -->
            <div>
                <h4 class="font-bold text-slate-800 text-sm mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
                    <i class="fa-solid fa-list-check text-emerald-600"></i> Deskripsi & Fitur
                </h4>

                <div class="space-y-4">
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Deskripsi Ringkas (Tampil di Kartu Katalog) *</label>
                        <textarea name="description" rows="2" required placeholder="Jelaskan secara singkat kegunaan sistem ini dalam 1-2 kalimat..." class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none leading-relaxed"><?= htmlspecialchars($app_data['description']) ?></textarea>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Deskripsi Lengkap (Tampil di Modal Detil)</label>
                        <textarea name="full_description" rows="4" placeholder="Uraian mendalam tentang kelebihan, modul-modul, dan alur kerja aplikasi..." class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none leading-relaxed"><?= htmlspecialchars($app_data['full_description']) ?></textarea>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Fitur Unggulan (Tulis per baris)</label>
                        <textarea name="features" rows="4" placeholder="Fitur 1&#10;Fitur 2&#10;Fitur 3" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"><?= htmlspecialchars($app_data['features']) ?></textarea>
                        <span class="text-[10px] text-slate-400">Setiap baris baru akan otomatis menjadi checklist poin fitur pada kartu & modal.</span>
                    </div>
                </div>
            </div>

            <!-- Section 4: Technical Specs -->
            <div>
                <h4 class="font-bold text-slate-800 text-sm mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
                    <i class="fa-solid fa-sliders text-amber-600"></i> Spesifikasi Teknis
                </h4>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Platform</label>
                        <input type="text" name="platform" value="<?= htmlspecialchars($app_data['platform']) ?>" placeholder="Web, Android, iOS" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Versi Rilis</label>
                        <input type="text" name="version" value="<?= htmlspecialchars($app_data['version']) ?>" placeholder="v2.1.0" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Tipe Lisensi</label>
                        <input type="text" name="license" value="<?= htmlspecialchars($app_data['license']) ?>" placeholder="Lisensi Seumur Hidup" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>

                    <div class="sm:col-span-2">
                        <label class="block font-semibold text-slate-700 mb-1.5">Tech Stack / Teknologi</label>
                        <input type="text" name="tech_stack" value="<?= htmlspecialchars($app_data['tech_stack']) ?>" placeholder="PHP 8, Tailwind CSS, SQLite, MySQL" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">URL Live Demo (Opsional)</label>
                        <input type="url" name="demo_url" value="<?= htmlspecialchars($app_data['demo_url']) ?>" placeholder="https://demo.aplikasi.com" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                </div>
            </div>

            <!-- Section 5: Badges & Status -->
            <div class="pt-2 flex flex-wrap items-center gap-6">
                <label class="flex items-center gap-2.5 cursor-pointer">
                    <input type="checkbox" name="is_featured" value="1" <?= !empty($app_data['is_featured']) ? 'checked' : '' ?> class="w-4 h-4 text-blue-600 rounded">
                    <span class="font-semibold text-slate-800">Tampilkan Badge Unggulan (Featured)</span>
                </label>

                <label class="flex items-center gap-2.5 cursor-pointer">
                    <input type="checkbox" name="is_active" value="1" <?= !empty($app_data['is_active']) ? 'checked' : '' ?> class="w-4 h-4 text-emerald-600 rounded">
                    <span class="font-semibold text-slate-800">Status Aktif (Tampil di Website Publik)</span>
                </label>
            </div>

            <!-- Submit Buttons -->
            <div class="pt-6 border-t border-slate-100 flex items-center justify-end gap-3">
                <a href="<?= base_url('admin/apps.php') ?>" class="px-5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition-colors">
                    Batal
                </a>
                <button type="submit" class="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-md shadow-blue-600/30 transition-all flex items-center gap-2">
                    <i class="fa-solid fa-check"></i>
                    <span>Simpan Data Aplikasi</span>
                </button>
            </div>
        </form>
    </div>

<?php 
// -------------------------------------------------------------------------
// VIEW: LIST APPS (DEFAULT)
// -------------------------------------------------------------------------
else: 
    $filter_cat = isset($_GET['category']) ? (int)$_GET['category'] : 0;
    $filter_search = clean_input($_GET['q'] ?? '');
    $filter_featured = isset($_GET['featured']) ? (int)$_GET['featured'] : null;

    $sql = "SELECT a.*, c.name as category_name FROM apps a LEFT JOIN categories c ON a.category_id = c.id WHERE 1=1";
    $params = [];

    if ($filter_cat > 0) {
        $sql .= " AND a.category_id = ?";
        $params[] = $filter_cat;
    }

    if (!empty($filter_search)) {
        $sql .= " AND (a.title LIKE ? OR a.description LIKE ?)";
        $params[] = "%$filter_search%";
        $params[] = "%$filter_search%";
    }

    if ($filter_featured !== null) {
        $sql .= " AND a.is_featured = ?";
        $params[] = $filter_featured;
    }

    $sql .= " ORDER BY a.sort_order ASC, a.id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $apps = $stmt->fetchAll();
?>

    <div class="space-y-6">
        <!-- Top Toolbar -->
        <div class="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
            <!-- Search & Filter Form -->
            <form action="" method="GET" class="w-full md:w-auto flex flex-wrap items-center gap-3 flex-1">
                <div class="relative flex-1 min-w-[200px]">
                    <i class="fa-solid fa-search absolute left-3.5 top-3 text-slate-400 text-xs"></i>
                    <input type="text" name="q" value="<?= htmlspecialchars($filter_search) ?>" placeholder="Cari nama aplikasi..." class="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>

                <select name="category" onchange="this.form.submit()" class="px-3.5 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white text-slate-700">
                    <option value="0">Semua Kategori</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= $filter_cat == $cat['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <?php if (!empty($filter_search) || $filter_cat > 0 || $filter_featured !== null): ?>
                    <a href="<?= base_url('admin/apps.php') ?>" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-semibold">
                        Reset
                    </a>
                <?php endif; ?>
            </form>

            <!-- Add Button -->
            <a href="<?= base_url('admin/apps.php?action=create') ?>" class="w-full md:w-auto text-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2">
                <i class="fa-solid fa-plus"></i>
                <span>Tambah Aplikasi Baru</span>
            </a>
        </div>

        <!-- Table Container -->
        <div class="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead>
                        <tr class="bg-slate-50/80 border-b border-slate-200/80 text-slate-500 uppercase tracking-wider text-[10px]">
                            <th class="py-3.5 px-6 font-semibold">Aplikasi</th>
                            <th class="py-3.5 px-4 font-semibold">Kategori</th>
                            <th class="py-3.5 px-4 font-semibold">Harga</th>
                            <th class="py-3.5 px-4 font-semibold">Platform</th>
                            <th class="py-3.5 px-4 font-semibold text-center">Unggulan</th>
                            <th class="py-3.5 px-4 font-semibold text-center">Status</th>
                            <th class="py-3.5 px-6 font-semibold text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php if (empty($apps)): ?>
                            <tr>
                                <td colspan="7" class="py-12 text-center text-slate-400">
                                    <i class="fa-solid fa-box-open text-4xl mb-3 text-slate-300 block"></i>
                                    Tidak ada aplikasi yang ditemukan.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($apps as $app): ?>
                                <?php
                                $fallback_img = 'https://placehold.co/100x100/0284c7/white?text=' . urlencode(substr($app['title'], 0, 3));
                                $img_src = $app['image'] ? (strpos($app['image'], 'http') === 0 ? $app['image'] : base_url($app['image'])) : $fallback_img;
                                ?>
                                <tr class="hover:bg-slate-50/60 transition-colors">
                                    <td class="py-3.5 px-6">
                                        <div class="flex items-center gap-3">
                                            <img src="<?= htmlspecialchars($img_src) ?>" onerror="this.src='<?= $fallback_img ?>'" class="w-12 h-12 rounded-xl object-cover border border-slate-200 flex-shrink-0">
                                            <div class="min-w-0">
                                                <h4 class="font-bold text-slate-800 text-sm truncate max-w-xs"><?= htmlspecialchars($app['title']) ?></h4>
                                                <span class="text-[10px] text-slate-400 font-mono block">slug: <?= htmlspecialchars($app['slug']) ?> &bull; <?= htmlspecialchars($app['version']) ?></span>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <span class="font-medium text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md text-[11px]">
                                            <?= htmlspecialchars($app['category_name'] ?? 'Umum') ?>
                                        </span>
                                    </td>
                                    <td class="py-3.5 px-4 font-extrabold text-blue-600">
                                        <?= format_rupiah($app['price']) ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-slate-600">
                                        <?= htmlspecialchars($app['platform']) ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-center">
                                        <form action="<?= base_url('admin/apps.php') ?>" method="POST" class="inline">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="toggle_featured">
                                            <input type="hidden" name="id" value="<?= $app['id'] ?>">
                                            <button type="submit" class="p-1 text-base transition-transform hover:scale-110" title="Klik untuk toggle unggulan">
                                                <i class="fa-solid fa-star <?= $app['is_featured'] ? 'text-amber-500' : 'text-slate-300 hover:text-amber-300' ?>"></i>
                                            </button>
                                        </form>
                                    </td>
                                    <td class="py-3.5 px-4 text-center">
                                        <form action="<?= base_url('admin/apps.php') ?>" method="POST" class="inline">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="action" value="toggle_active">
                                            <input type="hidden" name="id" value="<?= $app['id'] ?>">
                                            <button type="submit" class="px-2.5 py-1 rounded-full text-[10px] font-bold transition-all <?= $app['is_active'] ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200' : 'bg-slate-100 text-slate-500 hover:bg-slate-200' ?>" title="Klik untuk mengubah status">
                                                <?= $app['is_active'] ? 'Aktif' : 'Draft' ?>
                                            </button>
                                        </form>
                                    </td>
                                    <td class="py-3.5 px-6 text-right whitespace-nowrap">
                                        <div class="flex items-center justify-end gap-1.5">
                                            <!-- Duplicate -->
                                            <form action="<?= base_url('admin/apps.php') ?>" method="POST" class="inline" onsubmit="return confirm('Duplikasi aplikasi ini?')">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="duplicate">
                                                <input type="hidden" name="id" value="<?= $app['id'] ?>">
                                                <button type="submit" class="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Duplikasi">
                                                    <i class="fa-solid fa-copy"></i>
                                                </button>
                                            </form>

                                            <!-- Edit -->
                                            <a href="<?= base_url('admin/apps.php?action=edit&id=' . $app['id']) ?>" class="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Edit">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>

                                            <!-- Delete -->
                                            <form action="<?= base_url('admin/apps.php') ?>" method="POST" class="inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus aplikasi ini dari katalog?')">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?= $app['id'] ?>">
                                                <button type="submit" class="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors" title="Hapus">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Table Footer -->
            <div class="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-slate-500 text-[11px]">
                <span>Menampilkan <strong><?= count($apps) ?></strong> aplikasi dalam katalog.</span>
                <span class="text-slate-400">Database SQLite Terintegrasi</span>
            </div>
        </div>
    </div>

<?php endif; ?>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
