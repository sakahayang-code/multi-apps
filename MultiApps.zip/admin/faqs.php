<?php
/**
 * MultiApps Solutions - Admin FAQ Management
 */

$page_title = 'Tanya Jawab (FAQ)';
$page_subtitle = 'Kelola pertanyaan umum yang sering diajukan calon klien';

require_once __DIR__ . '/layout/header.php';

$pdo = get_db();
$error = '';
$edit_item = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('error', 'Token CSRF tidak valid.');
        header('Location: ' . base_url('admin/faqs.php'));
        exit;
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM faqs WHERE id = ?")->execute([$id]);
        set_flash('info', 'FAQ berhasil dihapus.');
        header('Location: ' . base_url('admin/faqs.php'));
        exit;
    }

    if ($action === 'toggle_active') {
        $id = (int)$_POST['id'];
        $pdo->prepare("UPDATE faqs SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?")->execute([$id]);
        set_flash('success', 'Status FAQ diperbarui.');
        header('Location: ' . base_url('admin/faqs.php'));
        exit;
    }

    if ($action === 'save') {
        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $question = clean_input($_POST['question'] ?? '');
        $answer = clean_input($_POST['answer'] ?? '');
        $sort_order = (int)($_POST['sort_order'] ?? 0);
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        if (empty($question) || empty($answer)) {
            $error = 'Pertanyaan dan jawaban tidak boleh kosong.';
        } else {
            if ($id) {
                $stmt = $pdo->prepare("UPDATE faqs SET question = ?, answer = ?, sort_order = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$question, $answer, $sort_order, $is_active, $id]);
                set_flash('success', 'FAQ berhasil diperbarui.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO faqs (question, answer, sort_order, is_active) VALUES (?, ?, ?, ?)");
                $stmt->execute([$question, $answer, $sort_order, $is_active]);
                set_flash('success', 'FAQ baru berhasil ditambahkan.');
            }
            header('Location: ' . base_url('admin/faqs.php'));
            exit;
        }
    }
}

if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM faqs WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_item = $stmt->fetch();
}

$faqs = $pdo->query("SELECT * FROM faqs ORDER BY sort_order ASC, id ASC")->fetchAll();
?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- Form Tambah / Edit FAQ -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm h-fit">
        <h3 class="font-bold text-slate-800 text-sm mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
            <i class="fa-solid <?= $edit_item ? 'fa-pen-to-square text-amber-500' : 'fa-plus text-blue-600' ?>"></i>
            <span><?= $edit_item ? 'Edit Pertanyaan FAQ' : 'Tambah FAQ Baru' ?></span>
        </h3>

        <?php if (!empty($error)): ?>
            <div class="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('admin/faqs.php') ?>" method="POST" class="space-y-4 text-xs">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $edit_item['id'] ?? '' ?>">

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Pertanyaan *</label>
                <input type="text" name="question" required value="<?= htmlspecialchars($edit_item['question'] ?? '') ?>" placeholder="Misal: Apakah bisa diinstal di cPanel Rumahweb?" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Jawaban Lengkap *</label>
                <textarea name="answer" rows="4" required placeholder="Jelaskan jawaban secara ramah dan informatif..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none leading-relaxed"><?= htmlspecialchars($edit_item['answer'] ?? '') ?></textarea>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Urutan Tampil (Sort Order)</label>
                <input type="number" name="sort_order" value="<?= htmlspecialchars($edit_item['sort_order'] ?? 0) ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div class="pt-1">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="is_active" value="1" <?= (!isset($edit_item) || !empty($edit_item['is_active'])) ? 'checked' : '' ?> class="w-4 h-4 text-blue-600 rounded">
                    <span class="font-semibold text-slate-700">Tampilkan di Halaman Depan</span>
                </label>
            </div>

            <div class="pt-2 flex items-center gap-2">
                <?php if ($edit_item): ?>
                    <a href="<?= base_url('admin/faqs.php') ?>" class="w-1/2 py-2.5 text-center bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-semibold">
                        Batal
                    </a>
                <?php endif; ?>
                <button type="submit" class="<?= $edit_item ? 'w-1/2' : 'w-full' ?> py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2">
                    <i class="fa-solid fa-check"></i>
                    <span><?= $edit_item ? 'Simpan Perubahan' : 'Tambah FAQ' ?></span>
                </button>
            </div>
        </form>
    </div>

    <!-- Daftar FAQ Terpasang -->
    <div class="lg:col-span-2 space-y-4">
        <div class="flex items-center justify-between mb-2">
            <h3 class="font-bold text-slate-800 text-base">Daftar Tanya Jawab Aktif</h3>
            <span class="text-xs text-slate-400">Total <?= count($faqs) ?> butir FAQ</span>
        </div>

        <?php if (empty($faqs)): ?>
            <div class="bg-white rounded-3xl border border-slate-200/80 p-8 text-center text-slate-400 text-xs">
                Belum ada pertanyaan FAQ yang dibuat.
            </div>
        <?php else: ?>
            <div class="space-y-3">
                <?php foreach ($faqs as $f): ?>
                    <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm text-xs space-y-2">
                        <div class="flex items-start justify-between gap-4">
                            <h4 class="font-bold text-slate-800 text-sm flex items-center gap-2">
                                <i class="fa-solid fa-circle-question text-blue-600"></i>
                                <?= htmlspecialchars($f['question']) ?>
                            </h4>

                            <div class="flex items-center gap-2 flex-shrink-0">
                                <form action="<?= base_url('admin/faqs.php') ?>" method="POST" class="inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="toggle_active">
                                    <input type="hidden" name="id" value="<?= $f['id'] ?>">
                                    <button type="submit" class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= $f['is_active'] ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500' ?>">
                                        <?= $f['is_active'] ? 'Aktif' : 'Draft' ?>
                                    </button>
                                </form>

                                <a href="<?= base_url('admin/faqs.php?edit=' . $f['id']) ?>" class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>

                                <form action="<?= base_url('admin/faqs.php') ?>" method="POST" class="inline" onsubmit="return confirm('Hapus FAQ ini?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $f['id'] ?>">
                                    <button type="submit" class="p-1.5 text-red-500 hover:bg-red-50 rounded-lg">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </div>
                        </div>

                        <p class="text-slate-600 leading-relaxed pl-6">
                            <?= nl2br(htmlspecialchars($f['answer'])) ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
