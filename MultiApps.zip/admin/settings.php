<?php
/**
 * MultiApps Solutions - Admin Settings & SQLite Database Tools
 */

$page_title = 'Pengaturan Website & Database';
$page_subtitle = 'Kelola identitas website, kontak WhatsApp, akun admin, dan backup SQLite';

require_once __DIR__ . '/layout/header.php';

$pdo = get_db();
$admin_info = current_user();

// Handle Direct Download SQLite Backup
if (isset($_GET['action']) && $_GET['action'] === 'download_db') {
    $db_file = __DIR__ . '/../database/multiapps.sqlite';
    if (file_exists($db_file)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/x-sqlite3');
        header('Content-Disposition: attachment; filename="multiapps_backup_' . date('Y-m-d_His') . '.sqlite"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($db_file));
        readfile($db_file);
        exit;
    } else {
        set_flash('error', 'File database SQLite tidak ditemukan.');
        header('Location: ' . base_url('admin/settings.php'));
        exit;
    }
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('error', 'Token CSRF tidak valid.');
        header('Location: ' . base_url('admin/settings.php'));
        exit;
    }

    // Save Website Settings
    if ($action === 'save_settings') {
        $fields = [
            'site_title', 'site_tagline', 'hero_title', 'hero_subtitle', 'hero_badge',
            'contact_email', 'contact_phone', 'contact_whatsapp', 'contact_address',
            'whatsapp_greeting', 'facebook_url', 'instagram_url', 'linkedin_url', 'github_url',
            'stat_clients', 'stat_uptime', 'stat_support'
        ];

        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                set_setting($field, clean_input($_POST[$field]));
            }
        }

        // Handle Logo Upload / Removal
        if (!empty($_POST['remove_logo'])) {
            $old_logo = get_setting('site_logo', '');
            if (!empty($old_logo) && strpos($old_logo, 'uploads/') === 0 && file_exists(__DIR__ . '/../' . $old_logo)) {
                @unlink(__DIR__ . '/../' . $old_logo);
            }
            set_setting('site_logo', '');
        } elseif (!empty($_FILES['logo_file']['name']) && $_FILES['logo_file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['logo_file'];
            $allowed_exts = ['png', 'jpg', 'jpeg', 'webp', 'svg', 'ico', 'gif'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, $allowed_exts)) {
                set_flash('error', 'Format logo tidak didukung. Harap unggah PNG, JPG, WebP, SVG, atau ICO.');
                header('Location: ' . base_url('admin/settings.php'));
                exit;
            }

            if ($file['size'] > 4 * 1024 * 1024) {
                set_flash('error', 'Ukuran file logo terlalu besar (maksimal 4MB).');
                header('Location: ' . base_url('admin/settings.php'));
                exit;
            }

            $upload_dir = __DIR__ . '/../uploads/';
            if (!file_exists($upload_dir)) {
                @mkdir($upload_dir, 0755, true);
            }

            $filename = 'logo_' . time() . '_' . bin2hex(random_bytes(2)) . '.' . $ext;
            $target = $upload_dir . $filename;

            if (move_uploaded_file($file['tmp_name'], $target)) {
                $old_logo = get_setting('site_logo', '');
                if (!empty($old_logo) && strpos($old_logo, 'uploads/') === 0 && file_exists(__DIR__ . '/../' . $old_logo)) {
                    @unlink(__DIR__ . '/../' . $old_logo);
                }
                set_setting('site_logo', 'uploads/' . $filename);
            } else {
                set_flash('error', 'Gagal memindahkan file logo ke folder uploads.');
                header('Location: ' . base_url('admin/settings.php'));
                exit;
            }
        } elseif (isset($_POST['logo_url']) && !empty(trim($_POST['logo_url']))) {
            set_setting('site_logo', clean_input($_POST['logo_url']));
        }

        set_flash('success', 'Pengaturan informasi website dan logo berhasil disimpan!');
        header('Location: ' . base_url('admin/settings.php'));
        exit;
    }

    // Update Admin Account
    if ($action === 'update_profile') {
        $name = clean_input($_POST['name'] ?? '');
        $username = clean_input($_POST['username'] ?? '');
        $email = clean_input($_POST['email'] ?? '');
        $current_pass = $_POST['current_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';
        $confirm_pass = $_POST['confirm_password'] ?? '';

        // Verify current password first
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
        $stmt->execute([$admin_info['id']]);
        $adm = $stmt->fetch();

        if (!$adm || !password_verify($current_pass, $adm['password'])) {
            set_flash('error', 'Kata sandi saat ini (lama) tidak cocok. Perubahan akun dibatalkan.');
            header('Location: ' . base_url('admin/settings.php'));
            exit;
        }

        if (!empty($new_pass)) {
            if (strlen($new_pass) < 6) {
                set_flash('error', 'Kata sandi baru minimal harus 6 karakter.');
                header('Location: ' . base_url('admin/settings.php'));
                exit;
            }
            if ($new_pass !== $confirm_pass) {
                set_flash('error', 'Konfirmasi kata sandi baru tidak sesuai.');
                header('Location: ' . base_url('admin/settings.php'));
                exit;
            }
            $final_hash = password_hash($new_pass, PASSWORD_BCRYPT);
            $upd = $pdo->prepare("UPDATE admins SET name = ?, username = ?, email = ?, password = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $upd->execute([$name, $username, $email, $final_hash, $admin_info['id']]);
        } else {
            $upd = $pdo->prepare("UPDATE admins SET name = ?, username = ?, email = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $upd->execute([$name, $username, $email, $admin_info['id']]);
        }

        // Update session
        $_SESSION['admin_name'] = $name;
        $_SESSION['admin_username'] = $username;
        $_SESSION['admin_email'] = $email;

        set_flash('success', 'Akun administrator berhasil diperbarui.');
        header('Location: ' . base_url('admin/settings.php'));
        exit;
    }

    // Optimize SQLite Database (VACUUM)
    if ($action === 'vacuum_db') {
        try {
            $pdo->exec("VACUUM;");
            $pdo->exec("ANALYZE;");
            set_flash('success', 'Database SQLite berhasil dioptimalkan (VACUUM & ANALYZE sukses).');
        } catch (Exception $e) {
            set_flash('error', 'Gagal mengoptimalkan database: ' . $e->getMessage());
        }
        header('Location: ' . base_url('admin/settings.php'));
        exit;
    }
}

// Fetch all settings
$settings = get_all_settings();

// Admin current details from DB
$adm_stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$adm_stmt->execute([$admin_info['id']]);
$current_db_admin = $adm_stmt->fetch();

$db_file_path = __DIR__ . '/../database/multiapps.sqlite';
$db_filesize = file_exists($db_file_path) ? round(filesize($db_file_path) / 1024, 2) . ' KB' : 'Tidak ditemukan';
?>

<div class="space-y-8 max-w-5xl">

    <!-- TAB 1: INFORMASI WEBSITE & HERO -->
    <div class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <h3 class="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
            <i class="fa-solid fa-globe text-blue-600"></i>
            <span>Informasi Identitas & Kontak Website</span>
        </h3>
        <p class="text-xs text-slate-400 mb-6 pb-4 border-b border-slate-100">
            Data ini digunakan untuk menampilkan nama brand, nomor WhatsApp tujuan pesanan, dan informasi kontak di halaman depan.
        </p>

        <form action="<?= base_url('admin/settings.php') ?>" method="POST" enctype="multipart/form-data" class="space-y-6 text-xs">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_settings">

            <!-- Logo & Favicon Uploader -->
            <div class="p-5 bg-blue-50/70 rounded-2xl border border-blue-200/80 shadow-sm">
                <div class="flex items-center gap-2 mb-2">
                    <i class="fa-solid fa-image text-blue-600 text-sm"></i>
                    <h4 class="font-bold text-slate-800 text-xs">Logo Website & Favicon Otomatis</h4>
                </div>
                <p class="text-[11px] text-slate-500 mb-4 leading-relaxed">
                    Unggah logo resmi website Anda. Logo ini akan <strong>secara otomatis terhubung sebagai Favicon</strong> (ikon tab browser), logo navigasi header publik, dan logo panel admin.
                </p>

                <div class="flex flex-col sm:flex-row items-start sm:items-center gap-5">
                    <!-- Preview Box -->
                    <div class="flex flex-col items-center gap-1.5 flex-shrink-0">
                        <span class="text-[10px] text-slate-400 font-semibold uppercase">Pratinjau Logo / Favicon</span>
                        <div class="w-16 h-16 rounded-2xl bg-white border border-slate-200 shadow-sm flex items-center justify-center p-2 overflow-hidden">
                            <?php $current_logo = get_site_logo(); ?>
                            <?php if (!empty($current_logo)): ?>
                                <img src="<?= htmlspecialchars($current_logo) ?>" id="logo-preview-img" alt="Logo Preview" class="w-full h-full object-contain">
                            <?php else: ?>
                                <div id="logo-preview-placeholder" class="w-full h-full rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white text-xl">
                                    <i class="fa-solid fa-cubes"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Upload Controls -->
                    <div class="flex-1 space-y-3 w-full">
                        <div>
                            <label class="block font-semibold text-slate-700 mb-1">Unggah File Logo Baru (PNG, JPG, WebP, SVG, ICO)</label>
                            <input type="file" name="logo_file" id="logo-file-input" accept="image/*,.ico" onchange="previewSelectedLogo(event)" class="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white file:mr-3 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 text-xs">
                            <span class="text-[10px] text-slate-400 block mt-1">Disarankan format PNG transparan atau SVG rasio persegi (1:1) untuk tampilan favicon yang jernih.</span>
                        </div>

                        <div>
                            <label class="block font-semibold text-slate-700 mb-1">Atau Masukkan Tautan URL Logo Eksternal</label>
                            <input type="url" name="logo_url" value="<?= htmlspecialchars(strpos($settings['site_logo'] ?? '', 'http') === 0 ? $settings['site_logo'] : '') ?>" placeholder="https://domain.com/assets/logo.png" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none">
                        </div>

                        <?php if (!empty($settings['site_logo'])): ?>
                            <div class="pt-1">
                                <label class="inline-flex items-center gap-2 cursor-pointer text-red-600 font-semibold hover:text-red-700">
                                    <input type="checkbox" name="remove_logo" value="1" class="w-4 h-4 text-red-600 rounded">
                                    <span>Hapus Logo Kustom & Kembalikan ke Logo Bawaan (Default Icon)</span>
                                </label>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block font-semibold text-slate-700 mb-1.5">Nama Website / Brand *</label>
                    <input type="text" name="site_title" required value="<?= htmlspecialchars($settings['site_title'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 mb-1.5">Tagline / Slogan</label>
                    <input type="text" name="site_tagline" value="<?= htmlspecialchars($settings['site_tagline'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>

                <div class="sm:col-span-2">
                    <label class="block font-semibold text-slate-700 mb-1.5">Badge Promo di Atas Hero</label>
                    <input type="text" name="hero_badge" value="<?= htmlspecialchars($settings['hero_badge'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>

                <div class="sm:col-span-2">
                    <label class="block font-semibold text-slate-700 mb-1.5">Judul Utama Hero (Hero Title) *</label>
                    <input type="text" name="hero_title" required value="<?= htmlspecialchars($settings['hero_title'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm font-semibold">
                </div>

                <div class="sm:col-span-2">
                    <label class="block font-semibold text-slate-700 mb-1.5">Sub-Judul Hero (Deskripsi Singkat)</label>
                    <textarea name="hero_subtitle" rows="3" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none leading-relaxed"><?= htmlspecialchars($settings['hero_subtitle'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Kontak & WhatsApp -->
            <div class="pt-4 border-t border-slate-100">
                <h4 class="font-bold text-slate-800 text-xs mb-3 flex items-center gap-2">
                    <i class="fa-brands fa-whatsapp text-emerald-500 text-sm"></i> Integrasi WhatsApp & Saluran Kontak
                </h4>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Nomor WhatsApp Admin (Untuk Menerima Order) *</label>
                        <input type="text" name="contact_whatsapp" required value="<?= htmlspecialchars($settings['contact_whatsapp'] ?? '6281234567890') ?>" placeholder="6281234567890" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono">
                        <span class="text-[10px] text-slate-400">Gunakan format 628... (tanpa tanda + atau spasi).</span>
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Nomor Telepon Ditampilkan</label>
                        <input type="text" name="contact_phone" value="<?= htmlspecialchars($settings['contact_phone'] ?? '') ?>" placeholder="+62 812-3456-7890" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>

                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Email Resmi</label>
                        <input type="email" name="contact_email" value="<?= htmlspecialchars($settings['contact_email'] ?? '') ?>" placeholder="support@multiapps.id" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>

                    <div class="sm:col-span-3">
                        <label class="block font-semibold text-slate-700 mb-1.5">Alamat Kantor / Studio</label>
                        <input type="text" name="contact_address" value="<?= htmlspecialchars($settings['contact_address'] ?? '') ?>" placeholder="Jakarta Tech Park, Tower A Fl 8, Jakarta" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>

                    <div class="sm:col-span-3">
                        <label class="block font-semibold text-slate-700 mb-1.5">Template Pembuka Chat WhatsApp Konsultasi</label>
                        <input type="text" name="whatsapp_greeting" value="<?= htmlspecialchars($settings['whatsapp_greeting'] ?? 'Halo MultiApps Solutions, saya ingin konsultasi mengenai aplikasi: ') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                </div>
            </div>

            <!-- Media Sosial -->
            <div class="pt-4 border-t border-slate-100">
                <h4 class="font-bold text-slate-800 text-xs mb-3 flex items-center gap-2">
                    <i class="fa-solid fa-share-nodes text-indigo-500 text-sm"></i> Tautan Media Sosial
                </h4>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Facebook URL</label>
                        <input type="url" name="facebook_url" value="<?= htmlspecialchars($settings['facebook_url'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">Instagram URL</label>
                        <input type="url" name="instagram_url" value="<?= htmlspecialchars($settings['instagram_url'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">LinkedIn URL</label>
                        <input type="url" name="linkedin_url" value="<?= htmlspecialchars($settings['linkedin_url'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1.5">GitHub URL</label>
                        <input type="url" name="github_url" value="<?= htmlspecialchars($settings['github_url'] ?? '') ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                </div>
            </div>

            <div class="pt-4 flex justify-end">
                <button type="submit" class="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-md shadow-blue-600/30 transition-all flex items-center gap-2">
                    <i class="fa-solid fa-floppy-disk"></i>
                    <span>Simpan Pengaturan Website</span>
                </button>
            </div>
        </form>
    </div>


    <!-- TAB 2: AKUN ADMINISTRATOR & GANTI PASSWORD -->
    <div class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <h3 class="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
            <i class="fa-solid fa-user-shield text-indigo-600"></i>
            <span>Akun Pengelola & Keamanan Kata Sandi</span>
        </h3>
        <p class="text-xs text-slate-400 mb-6 pb-4 border-b border-slate-100">
            Ubah nama tampilan, email pengelola, dan perbarui kata sandi untuk mengamankan akses ke panel admin.
        </p>

        <form action="<?= base_url('admin/settings.php') ?>" method="POST" class="space-y-4 text-xs">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="update_profile">

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                    <label class="block font-semibold text-slate-700 mb-1.5">Nama Lengkap Pengelola *</label>
                    <input type="text" name="name" required value="<?= htmlspecialchars($current_db_admin['name'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 mb-1.5">Username Login *</label>
                    <input type="text" name="username" required value="<?= htmlspecialchars($current_db_admin['username'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono">
                </div>

                <div>
                    <label class="block font-semibold text-slate-700 mb-1.5">Email Administrator *</label>
                    <input type="email" name="email" required value="<?= htmlspecialchars($current_db_admin['email'] ?? '') ?>" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>
            </div>

            <!-- Ganti Password -->
            <div class="mt-4 p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                <h4 class="font-bold text-slate-800 text-xs">Perbarui Kata Sandi (Kosongkan bila tidak ingin mengubah)</h4>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1">Kata Sandi Baru</label>
                        <input type="password" name="new_password" placeholder="Minimal 6 karakter" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                    <div>
                        <label class="block font-semibold text-slate-700 mb-1">Ulangi Kata Sandi Baru</label>
                        <input type="password" name="confirm_password" placeholder="Ketik ulang kata sandi baru" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                    </div>
                </div>

                <div class="pt-2 border-t border-slate-200">
                    <label class="block font-semibold text-red-600 mb-1">Masukkan Kata Sandi Saat Ini (Konfirmasi Keamanan) *</label>
                    <input type="password" name="current_password" required placeholder="Ketik kata sandi Anda saat ini" class="w-full sm:w-1/2 px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-red-500 focus:outline-none bg-white">
                </div>
            </div>

            <div class="pt-4 flex justify-end">
                <button type="submit" class="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-md shadow-indigo-600/30 transition-all flex items-center gap-2">
                    <i class="fa-solid fa-lock"></i>
                    <span>Perbarui Akun & Sandi</span>
                </button>
            </div>
        </form>
    </div>


    <!-- TAB 3: MANAJEMEN DATABASE SQLITE & HOSTING TOOLS -->
    <div class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        <h3 class="text-base font-bold text-slate-800 mb-2 flex items-center gap-2">
            <i class="fa-solid fa-database text-emerald-600"></i>
            <span>Pemeliharaan & Backup Database SQLite (Rumahweb Ready)</span>
        </h3>
        <p class="text-xs text-slate-400 mb-6 pb-4 border-b border-slate-100">
            Aplikasi menggunakan penyimpanan SQLite yang ringan, mandiri, dan tidak membutuhkan konfigurasi server MySQL. Unduh file cadangan kapan saja.
        </p>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Download Backup -->
            <div class="p-6 rounded-2xl bg-emerald-50/60 border border-emerald-200 flex flex-col justify-between">
                <div>
                    <div class="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-lg mb-3">
                        <i class="fa-solid fa-cloud-arrow-down"></i>
                    </div>
                    <h4 class="font-bold text-slate-800 text-sm">Unduh File Backup Database</h4>
                    <p class="text-xs text-slate-600 mt-1 leading-relaxed">
                        Unduh salinan langsung file <code class="bg-white px-1.5 py-0.5 rounded text-emerald-800 font-mono text-[11px]">multiapps.sqlite</code> (Ukuran: <strong><?= $db_filesize ?></strong>). Anda dapat menyimpannya di komputer lokal untuk cadangan data.
                    </p>
                </div>
                <div class="mt-5">
                    <a href="<?= base_url('admin/settings.php?action=download_db') ?>" class="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-xl shadow-md shadow-emerald-600/20 transition-all">
                        <i class="fa-solid fa-download"></i>
                        <span>Unduh Backup .sqlite Sekarang</span>
                    </a>
                </div>
            </div>

            <!-- Optimize SQLite -->
            <div class="p-6 rounded-2xl bg-blue-50/60 border border-blue-200 flex flex-col justify-between">
                <div>
                    <div class="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center text-lg mb-3">
                        <i class="fa-solid fa-wrench"></i>
                    </div>
                    <h4 class="font-bold text-slate-800 text-sm">Optimasi & Kompresi Database (VACUUM)</h4>
                    <p class="text-xs text-slate-600 mt-1 leading-relaxed">
                        Jalankan proses <code class="bg-white px-1.5 py-0.5 rounded text-blue-800 font-mono text-[11px]">VACUUM</code> dan <code class="bg-white px-1.5 py-0.5 rounded text-blue-800 font-mono text-[11px]">ANALYZE</code> pada SQLite untuk membersihkan ruang kosong sisa penghapusan data dan mempercepat query.
                    </p>
                </div>
                <div class="mt-5">
                    <form action="<?= base_url('admin/settings.php') ?>" method="POST" onsubmit="return confirm('Jalankan proses optimasi database sekarang?')">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="vacuum_db">
                        <button type="submit" class="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl shadow-md shadow-blue-600/20 transition-all">
                            <i class="fa-solid fa-gauge-high"></i>
                            <span>Jalankan Optimasi Database</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="mt-6 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-3">
            <i class="fa-solid fa-shield-halved text-emerald-600 text-base mt-0.5"></i>
            <div>
                <p class="font-bold text-slate-800">Proteksi Keamanan Database Aktif</p>
                <p class="text-slate-500 mt-0.5 leading-relaxed">
                    File database SQLite berada di dalam folder <code class="bg-white px-1 py-0.5 rounded font-mono">database/</code> yang diproteksi oleh file <code class="bg-white px-1 py-0.5 rounded font-mono">.htaccess</code> dengan aturan <em>Require all denied</em>. Pengunjung website dari browser luar diblokir secara otomatis sehingga tidak dapat mengunduh database Anda secara ilegal.
                </p>
            </div>
        </div>
    </div>

</div>

<script>
    function previewSelectedLogo(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const previewImg = document.getElementById('logo-preview-img');
                const placeholder = document.getElementById('logo-preview-placeholder');
                if (previewImg) {
                    previewImg.src = e.target.result;
                } else if (placeholder) {
                    placeholder.outerHTML = `<img src="${e.target.result}" id="logo-preview-img" alt="Logo Preview" class="w-full h-full object-contain">`;
                }
            };
            reader.readAsDataURL(file);
        }
    }
</script>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
