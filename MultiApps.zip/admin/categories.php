<?php
/**
 * MultiApps Solutions - Admin Category Management
 */

$page_title = 'Kategori Aplikasi';
$page_subtitle = 'Kelola klasifikasi sistem dan pengelompokan produk software';

require_once __DIR__ . '/layout/header.php';

$pdo = get_db();
$error = '';
$edit_cat = null;

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('error', 'Token CSRF tidak valid.');
        header('Location: ' . base_url('admin/categories.php'));
        exit;
    }

    // Delete
    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        // Check if apps exist in this category
        $count = $pdo->prepare("SELECT COUNT(*) FROM apps WHERE category_id = ?");
        $count->execute([$id]);
        $apps_in_cat = $count->fetchColumn();

        if ($apps_in_cat > 0) {
            set_flash('error', "Kategori tidak dapat dihapus karena masih digunakan oleh {$apps_in_cat} aplikasi. Silakan pindahkan atau hapus aplikasi terkait terlebih dahulu.");
        } else {
            $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
            set_flash('info', 'Kategori berhasil dihapus.');
        }
        header('Location: ' . base_url('admin/categories.php'));
        exit;
    }

    // Save (Add or Edit)
    if ($action === 'save') {
        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $name = clean_input($_POST['name'] ?? '');
        $slug = !empty($_POST['slug']) ? slugify($_POST['slug']) : slugify($name);
        $icon = clean_input($_POST['icon'] ?? 'fa-layer-group');
        $sort_order = (int)($_POST['sort_order'] ?? 0);

        if (empty($name)) {
            $error = 'Nama kategori tidak boleh kosong.';
        } else {
            if ($id) {
                // Update
                $stmt = $pdo->prepare("UPDATE categories SET name = ?, slug = ?, icon = ?, sort_order = ? WHERE id = ?");
                $stmt->execute([$name, $slug, $icon, $sort_order, $id]);
                set_flash('success', "Kategori '{$name}' berhasil diperbarui.");
            } else {
                // Check unique
                $check = $pdo->prepare("SELECT id FROM categories WHERE name = ? OR slug = ?");
                $check->execute([$name, $slug]);
                if ($check->fetch()) {
                    $error = 'Kategori dengan nama atau slug ini sudah terdaftar.';
                } else {
                    $stmt = $pdo->prepare("INSERT INTO categories (name, slug, icon, sort_order) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$name, $slug, $icon, $sort_order]);
                    set_flash('success', "Kategori baru '{$name}' berhasil ditambahkan.");
                }
            }

            if (empty($error)) {
                header('Location: ' . base_url('admin/categories.php'));
                exit;
            }
        }
    }
}

// Check if editing
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_cat = $stmt->fetch();
}

// Fetch all categories with count of apps
$categories = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM apps a WHERE a.category_id = c.id) as apps_count FROM categories c ORDER BY c.sort_order ASC, c.name ASC")->fetchAll();
?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- Form Tambah / Edit Kategori -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm h-fit">
        <h3 class="font-bold text-slate-800 text-sm mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
            <i class="fa-solid <?= $edit_cat ? 'fa-pen-to-square text-amber-500' : 'fa-plus text-blue-600' ?>"></i>
            <span><?= $edit_cat ? 'Edit Kategori: ' . htmlspecialchars($edit_cat['name']) : 'Tambah Kategori Baru' ?></span>
        </h3>

        <?php if (!empty($error)): ?>
            <div class="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('admin/categories.php') ?>" method="POST" class="space-y-4 text-xs">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $edit_cat['id'] ?? '' ?>">

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Nama Kategori *</label>
                <input type="text" name="name" required value="<?= htmlspecialchars($edit_cat['name'] ?? '') ?>" placeholder="Contoh: POS & Kasir" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Slug URL</label>
                <input type="text" name="slug" value="<?= htmlspecialchars($edit_cat['slug'] ?? '') ?>" placeholder="pos-kasir (otomatis jika kosong)" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Ikon FontAwesome</label>
                <div class="flex items-center gap-2">
                    <span class="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-700 text-base flex-shrink-0" id="icon-preview">
                        <i class="fa-solid <?= htmlspecialchars($edit_cat['icon'] ?? 'fa-layer-group') ?>"></i>
                    </span>
                    <input type="text" name="icon" id="icon-input" onkeyup="updateIconPreview(this.value)" value="<?= htmlspecialchars($edit_cat['icon'] ?? 'fa-layer-group') ?>" placeholder="fa-cash-register" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono">
                </div>
                <span class="text-[10px] text-slate-400 mt-1 block">Contoh: fa-cash-register, fa-cart-shopping, fa-hospital, fa-school</span>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Urutan Tampil (Sort Order)</label>
                <input type="number" name="sort_order" value="<?= htmlspecialchars($edit_cat['sort_order'] ?? 0) ?>" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div class="pt-2 flex items-center gap-2">
                <?php if ($edit_cat): ?>
                    <a href="<?= base_url('admin/categories.php') ?>" class="w-1/2 py-2.5 text-center bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-semibold">
                        Batal
                    </a>
                <?php endif; ?>
                <button type="submit" class="<?= $edit_cat ? 'w-1/2' : 'w-full' ?> py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2">
                    <i class="fa-solid fa-check"></i>
                    <span><?= $edit_cat ? 'Simpan Perubahan' : 'Tambah Kategori' ?></span>
                </button>
            </div>
        </form>
    </div>

    <!-- Daftar Kategori Terpasang -->
    <div class="lg:col-span-2 bg-white rounded-3xl border border-slate-200/80 p-6 shadow-sm">
        <div class="flex items-center justify-between mb-5">
            <div>
                <h3 class="font-bold text-slate-800 text-base">Daftar Kategori Tersedia</h3>
                <p class="text-xs text-slate-400">Total <?= count($categories) ?> kategori sistem terdaftar</p>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
                <thead>
                    <tr class="border-b border-slate-100 text-slate-400 uppercase tracking-wider text-[10px]">
                        <th class="pb-3 font-semibold">Ikon & Nama Kategori</th>
                        <th class="pb-3 font-semibold">Slug URL</th>
                        <th class="pb-3 font-semibold text-center">Jumlah App</th>
                        <th class="pb-3 font-semibold text-center">Urutan</th>
                        <th class="pb-3 font-semibold text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php foreach ($categories as $cat): ?>
                        <tr class="hover:bg-slate-50 transition-colors">
                            <td class="py-3.5 pr-2">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-sm flex-shrink-0">
                                        <i class="fa-solid <?= htmlspecialchars($cat['icon']) ?>"></i>
                                    </div>
                                    <span class="font-bold text-slate-800"><?= htmlspecialchars($cat['name']) ?></span>
                                </div>
                            </td>
                            <td class="py-3.5 pr-2 font-mono text-slate-500">
                                <?= htmlspecialchars($cat['slug']) ?>
                            </td>
                            <td class="py-3.5 pr-2 text-center">
                                <a href="<?= base_url('admin/apps.php?category=' . $cat['id']) ?>" class="inline-block bg-slate-100 hover:bg-blue-100 hover:text-blue-700 text-slate-700 font-bold px-2.5 py-1 rounded-full text-[11px] transition-colors">
                                    <?= $cat['apps_count'] ?> Aplikasi
                                </a>
                            </td>
                            <td class="py-3.5 pr-2 text-center text-slate-400 font-mono">
                                <?= $cat['sort_order'] ?>
                            </td>
                            <td class="py-3.5 text-right whitespace-nowrap">
                                <div class="flex items-center justify-end gap-1">
                                    <a href="<?= base_url('admin/categories.php?edit=' . $cat['id']) ?>" class="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Edit">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <form action="<?= base_url('admin/categories.php') ?>" method="POST" class="inline" onsubmit="return confirm('Hapus kategori <?= addslashes($cat['name']) ?>?')">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $cat['id'] ?>">
                                        <button type="submit" class="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors" title="Hapus">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    function updateIconPreview(val) {
        val = val.trim();
        const preview = document.getElementById('icon-preview');
        preview.innerHTML = `<i class="fa-solid ${val}"></i>`;
    }
</script>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
