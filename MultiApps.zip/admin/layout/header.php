<?php
/**
 * MultiApps Solutions - Admin Header & Navigation Layout
 */

if (!defined('MULTITAPPS_APP')) {
    define('MULTITAPPS_APP', true);
}

require_once __DIR__ . '/../../includes/auth.php';
require_login();

$current_admin = current_user();
$pdo = get_db();

// Count badges
$pending_inq_count = $pdo->query("SELECT COUNT(*) FROM inquiries WHERE status = 'Baru'")->fetchColumn();
$total_apps_count = $pdo->query("SELECT COUNT(*) FROM apps")->fetchColumn();
$site_title = get_setting('site_title', 'MultiApps Solutions');

$current_page = basename($_SERVER['PHP_SELF']);
$flash = get_flash();

$admin_logo = get_site_logo();
$admin_favicon = get_site_favicon();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) . ' - ' : '' ?>Admin Panel | <?= htmlspecialchars($site_title) ?></title>

    <!-- Favicon (Terkoneksi Otomatis dengan Logo Website) -->
    <?php if (!empty($admin_favicon)): ?>
        <link rel="icon" href="<?= htmlspecialchars($admin_favicon) ?>">
        <link rel="shortcut icon" href="<?= htmlspecialchars($admin_favicon) ?>">
        <link rel="apple-touch-icon" href="<?= htmlspecialchars($admin_favicon) ?>">
    <?php endif; ?>

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome 6 Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        brand: {
                            50: '#f0f7ff',
                            100: '#e0effe',
                            500: '#0284c7',
                            600: '#0284c7',
                            700: '#0369a1',
                            800: '#075985',
                            900: '#0c4a6e',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .custom-scrollbar::-webkit-scrollbar {
            width: 5px;
            height: 5px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #0f172a;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #334155;
            border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #475569;
        }
    </style>
</head>
<body class="bg-slate-100 text-slate-800 font-sans antialiased min-h-screen flex flex-col md:flex-row">

    <!-- Toast Notification Container -->
    <div id="toast-container" class="fixed top-5 right-5 z-50 flex flex-col gap-2 pointer-events-none"></div>

    <!-- Mobile Sidebar Backdrop -->
    <div id="mobile-sidebar-backdrop" onclick="toggleSidebar(false)" class="fixed inset-0 bg-slate-900/60 z-30 hidden md:hidden"></div>

    <!-- ADMIN SIDEBAR -->
    <aside id="admin-sidebar" class="fixed md:static inset-y-0 left-0 z-40 w-64 bg-slate-900 text-white flex flex-col border-r border-slate-800 transform -translate-x-full md:translate-x-0 transition-transform duration-200 ease-in-out flex-shrink-0">
        <!-- Brand Header -->
        <div class="h-20 px-6 border-b border-slate-800 flex items-center justify-between">
            <a href="<?= base_url('admin/index.php') ?>" class="flex items-center gap-3">
                <?php if (!empty($admin_logo)): ?>
                    <img src="<?= htmlspecialchars($admin_logo) ?>" alt="Logo" class="w-10 h-10 rounded-xl object-contain bg-white/10 p-1 shadow-md shadow-blue-500/10">
                <?php else: ?>
                    <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold shadow-md shadow-blue-500/20">
                        <i class="fa-solid fa-sliders text-lg"></i>
                    </div>
                <?php endif; ?>
                <div>
                    <h3 class="font-bold text-sm leading-tight text-white">Admin Panel</h3>
                    <p class="text-[11px] text-blue-400 font-medium tracking-wide"><?= htmlspecialchars($site_title) ?></p>
                </div>
            </a>
            <button onclick="toggleSidebar(false)" class="md:hidden text-slate-400 hover:text-white p-2">
                <i class="fa-solid fa-xmark text-lg"></i>
            </button>
        </div>

        <!-- Admin Profile Info -->
        <div class="px-6 py-4 border-b border-slate-800/80 bg-slate-900/50 flex items-center gap-3">
            <div class="w-9 h-9 rounded-full bg-blue-600/30 border border-blue-500/40 text-blue-400 font-bold flex items-center justify-center text-xs">
                <?= strtoupper(substr($current_admin['username'], 0, 2)) ?>
            </div>
            <div class="overflow-hidden">
                <p class="text-xs font-semibold text-slate-200 truncate"><?= htmlspecialchars($current_admin['name']) ?></p>
                <p class="text-[10px] text-emerald-400 flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Online (Admin)</p>
            </div>
        </div>

        <!-- Navigation Menu -->
        <nav class="flex-1 px-4 py-5 space-y-1.5 overflow-y-auto custom-scrollbar text-xs font-medium">
            <a href="<?= base_url('admin/index.php') ?>" class="flex items-center justify-between px-3.5 py-3 rounded-xl transition-all <?= $current_page === 'index.php' ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-gauge text-sm w-4 text-center"></i>
                    <span>Dashboard Utama</span>
                </div>
            </a>

            <a href="<?= base_url('admin/apps.php') ?>" class="flex items-center justify-between px-3.5 py-3 rounded-xl transition-all <?= $current_page === 'apps.php' ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-box text-sm w-4 text-center"></i>
                    <span>Katalog Aplikasi</span>
                </div>
                <span class="bg-slate-800 text-slate-300 text-[10px] px-2 py-0.5 rounded-full"><?= $total_apps_count ?></span>
            </a>

            <a href="<?= base_url('admin/categories.php') ?>" class="flex items-center justify-between px-3.5 py-3 rounded-xl transition-all <?= $current_page === 'categories.php' ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-tags text-sm w-4 text-center"></i>
                    <span>Kategori Aplikasi</span>
                </div>
            </a>

            <a href="<?= base_url('admin/inquiries.php') ?>" class="flex items-center justify-between px-3.5 py-3 rounded-xl transition-all <?= $current_page === 'inquiries.php' ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-inbox text-sm w-4 text-center"></i>
                    <span>Pesanan & Inquiry</span>
                </div>
                <?php if ($pending_inq_count > 0): ?>
                    <span class="bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse"><?= $pending_inq_count ?></span>
                <?php endif; ?>
            </a>

            <a href="<?= base_url('admin/testimonials.php') ?>" class="flex items-center justify-between px-3.5 py-3 rounded-xl transition-all <?= $current_page === 'testimonials.php' ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-star text-sm w-4 text-center"></i>
                    <span>Ulasan & Testimoni</span>
                </div>
            </a>

            <a href="<?= base_url('admin/faqs.php') ?>" class="flex items-center justify-between px-3.5 py-3 rounded-xl transition-all <?= $current_page === 'faqs.php' ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-circle-question text-sm w-4 text-center"></i>
                    <span>Kelola FAQ</span>
                </div>
            </a>

            <div class="pt-4 pb-1">
                <span class="px-3.5 text-[10px] font-bold uppercase tracking-wider text-slate-500">Sistem & Hosting</span>
            </div>

            <a href="<?= base_url('admin/settings.php') ?>" class="flex items-center justify-between px-3.5 py-3 rounded-xl transition-all <?= $current_page === 'settings.php' ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-gear text-sm w-4 text-center"></i>
                    <span>Pengaturan Website</span>
                </div>
            </a>

            <a href="<?= base_url() ?>" target="_blank" class="flex items-center justify-between px-3.5 py-3 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-all">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-globe text-sm w-4 text-center text-blue-400"></i>
                    <span>Buka Web Depan</span>
                </div>
                <i class="fa-solid fa-arrow-up-right-from-square text-[10px] text-slate-500"></i>
            </a>
        </nav>

        <!-- Sidebar Footer -->
        <div class="p-4 border-t border-slate-800">
            <a href="<?= base_url('admin/logout.php') ?>" onclick="return confirm('Apakah Anda yakin ingin keluar dari panel admin?')" class="w-full py-2.5 px-4 bg-slate-800 hover:bg-red-600/80 text-slate-300 hover:text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Keluar (Logout)</span>
            </a>
        </div>
    </aside>

    <!-- MAIN BODY CONTENT WRAPPER -->
    <div class="flex-1 flex flex-col min-w-0 min-h-screen">
        <!-- TOPBAR HEADER -->
        <header class="bg-white border-b border-slate-200 h-20 px-4 sm:px-8 flex items-center justify-between sticky top-0 z-20 shadow-sm">
            <div class="flex items-center gap-3">
                <button onclick="toggleSidebar(true)" class="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg">
                    <i class="fa-solid fa-bars text-xl"></i>
                </button>
                <div>
                    <h1 class="text-lg sm:text-xl font-bold text-slate-900 leading-tight"><?= $page_title ?? 'Dashboard' ?></h1>
                    <p class="text-xs text-slate-500 hidden sm:block"><?= $page_subtitle ?? 'Kelola aplikasi dan operasional digital MultiApps' ?></p>
                </div>
            </div>

            <div class="flex items-center gap-3">
                <a href="<?= base_url('admin/apps.php?action=create') ?>" class="hidden sm:inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-md shadow-blue-600/20 transition-all">
                    <i class="fa-solid fa-plus"></i> Tambah Aplikasi
                </a>
                <a href="<?= base_url() ?>" target="_blank" class="p-2.5 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-xl transition-colors border border-slate-200 text-xs font-semibold flex items-center gap-2" title="Kunjungi Website Depan">
                    <i class="fa-solid fa-desktop"></i>
                    <span class="hidden md:inline">Website Depan</span>
                </a>
            </div>
        </header>

        <!-- FLASH NOTIFICATION -->
        <?php if ($flash): ?>
            <div class="px-4 sm:px-8 pt-6">
                <div class="p-4 rounded-2xl flex items-center gap-3 <?= $flash['type'] === 'success' ? 'bg-emerald-50 border border-emerald-200 text-emerald-800' : ($flash['type'] === 'error' ? 'bg-red-50 border border-red-200 text-red-800' : 'bg-blue-50 border border-blue-200 text-blue-800') ?>">
                    <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check text-emerald-600' : ($flash['type'] === 'error' ? 'fa-triangle-exclamation text-red-600' : 'fa-circle-info text-blue-600') ?> text-lg"></i>
                    <p class="text-sm font-medium"><?= htmlspecialchars($flash['message']) ?></p>
                </div>
            </div>
        <?php endif; ?>

        <!-- MAIN VIEWPORT CONTENT -->
        <main class="flex-1 p-4 sm:p-8">
