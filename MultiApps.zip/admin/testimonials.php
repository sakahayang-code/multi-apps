<?php
/**
 * MultiApps Solutions - Admin Testimonials Management
 */

$page_title = 'Ulasan & Testimoni Klien';
$page_subtitle = 'Kelola testimoni mitra bisnis untuk membangun kredibilitas website';

require_once __DIR__ . '/layout/header.php';

$pdo = get_db();
$error = '';
$edit_item = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('error', 'Token CSRF tidak valid.');
        header('Location: ' . base_url('admin/testimonials.php'));
        exit;
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM testimonials WHERE id = ?")->execute([$id]);
        set_flash('info', 'Testimoni berhasil dihapus.');
        header('Location: ' . base_url('admin/testimonials.php'));
        exit;
    }

    if ($action === 'toggle_active') {
        $id = (int)$_POST['id'];
        $pdo->prepare("UPDATE testimonials SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = ?")->execute([$id]);
        set_flash('success', 'Status tampil testimoni diperbarui.');
        header('Location: ' . base_url('admin/testimonials.php'));
        exit;
    }

    if ($action === 'save') {
        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $client_name = clean_input($_POST['client_name'] ?? '');
        $client_role = clean_input($_POST['client_role'] ?? '');
        $company = clean_input($_POST['company'] ?? '');
        $avatar = clean_input($_POST['avatar'] ?? strtoupper(substr($client_name, 0, 2)));
        $review = clean_input($_POST['review'] ?? '');
        $rating = (int)($_POST['rating'] ?? 5);
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        if (empty($client_name) || empty($review)) {
            $error = 'Nama klien dan isi ulasan wajib diisi.';
        } else {
            if ($id) {
                $stmt = $pdo->prepare("UPDATE testimonials SET client_name = ?, client_role = ?, company = ?, avatar = ?, review = ?, rating = ?, is_active = ? WHERE id = ?");
                $stmt->execute([$client_name, $client_role, $company, $avatar, $review, $rating, $is_active, $id]);
                set_flash('success', 'Testimoni berhasil diperbarui.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO testimonials (client_name, client_role, company, avatar, review, rating, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$client_name, $client_role, $company, $avatar, $review, $rating, $is_active]);
                set_flash('success', 'Testimoni baru berhasil ditambahkan.');
            }
            header('Location: ' . base_url('admin/testimonials.php'));
            exit;
        }
    }
}

if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM testimonials WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_item = $stmt->fetch();
}

$testimonials = $pdo->query("SELECT * FROM testimonials ORDER BY id DESC")->fetchAll();
?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- Form Tambah / Edit -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm h-fit">
        <h3 class="font-bold text-slate-800 text-sm mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
            <i class="fa-solid <?= $edit_item ? 'fa-pen-to-square text-amber-500' : 'fa-plus text-blue-600' ?>"></i>
            <span><?= $edit_item ? 'Edit Testimoni Klien' : 'Tambah Testimoni Baru' ?></span>
        </h3>

        <?php if (!empty($error)): ?>
            <div class="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                <span><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('admin/testimonials.php') ?>" method="POST" class="space-y-4 text-xs">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $edit_item['id'] ?? '' ?>">

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Nama Klien / Tokoh *</label>
                <input type="text" name="client_name" required value="<?= htmlspecialchars($edit_item['client_name'] ?? '') ?>" placeholder="Contoh: Ahmad Hidayat" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block font-semibold text-slate-700 mb-1.5">Jabatan / Role</label>
                    <input type="text" name="client_role" value="<?= htmlspecialchars($edit_item['client_role'] ?? '') ?>" placeholder="Owner / HR Manager" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
                </div>
                <div>
                    <label class="block font-semibold text-slate-700 mb-1.5">Inisial / Foto (Text)</label>
                    <input type="text" name="avatar" value="<?= htmlspecialchars($edit_item['avatar'] ?? '') ?>" placeholder="AH" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none font-bold uppercase">
                </div>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Nama Perusahaan / Bisnis</label>
                <input type="text" name="company" value="<?= htmlspecialchars($edit_item['company'] ?? '') ?>" placeholder="Retail Mart Nusantara" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Rating Bintang (1 - 5)</label>
                <select name="rating" class="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white">
                    <?php for ($r = 5; $r >= 1; $r--): ?>
                        <option value="<?= $r ?>" <?= ($edit_item['rating'] ?? 5) == $r ? 'selected' : '' ?>>
                            <?= $r ?> Bintang <?= str_repeat('★', $r) ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>

            <div>
                <label class="block font-semibold text-slate-700 mb-1.5">Isi Ulasan / Testimoni *</label>
                <textarea name="review" rows="3" required placeholder="Tuliskan pengalaman klien menggunakan aplikasi..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none"><?= htmlspecialchars($edit_item['review'] ?? '') ?></textarea>
            </div>

            <div class="pt-1">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="is_active" value="1" <?= (!isset($edit_item) || !empty($edit_item['is_active'])) ? 'checked' : '' ?> class="w-4 h-4 text-blue-600 rounded">
                    <span class="font-semibold text-slate-700">Tampilkan di Halaman Depan</span>
                </label>
            </div>

            <div class="pt-2 flex items-center gap-2">
                <?php if ($edit_item): ?>
                    <a href="<?= base_url('admin/testimonials.php') ?>" class="w-1/2 py-2.5 text-center bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-semibold">
                        Batal
                    </a>
                <?php endif; ?>
                <button type="submit" class="<?= $edit_item ? 'w-1/2' : 'w-full' ?> py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2">
                    <i class="fa-solid fa-check"></i>
                    <span><?= $edit_item ? 'Simpan Perubahan' : 'Tambah Testimoni' ?></span>
                </button>
            </div>
        </form>
    </div>

    <!-- Daftar Testimoni -->
    <div class="lg:col-span-2 space-y-4">
        <div class="flex items-center justify-between mb-2">
            <h3 class="font-bold text-slate-800 text-base">Daftar Testimoni Klien</h3>
            <span class="text-xs text-slate-400">Total <?= count($testimonials) ?> ulasan</span>
        </div>

        <?php if (empty($testimonials)): ?>
            <div class="bg-white rounded-3xl border border-slate-200/80 p-8 text-center text-slate-400 text-xs">
                Belum ada testimoni.
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php foreach ($testimonials as $t): ?>
                    <div class="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm flex flex-col justify-between text-xs space-y-3">
                        <div>
                            <div class="flex items-center justify-between mb-2">
                                <div class="text-amber-500">
                                    <?= str_repeat('<i class="fa-solid fa-star"></i>', (int)$t['rating']) ?>
                                </div>
                                <form action="<?= base_url('admin/testimonials.php') ?>" method="POST" class="inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="toggle_active">
                                    <input type="hidden" name="id" value="<?= $t['id'] ?>">
                                    <button type="submit" class="px-2 py-0.5 rounded-full text-[10px] font-bold <?= $t['is_active'] ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500' ?>">
                                        <?= $t['is_active'] ? 'Tampil' : 'Disembunyikan' ?>
                                    </button>
                                </form>
                            </div>
                            <p class="text-slate-600 italic leading-relaxed">"<?= htmlspecialchars($t['review']) ?>"</p>
                        </div>

                        <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
                            <div class="flex items-center gap-2.5">
                                <div class="w-8 h-8 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xs">
                                    <?= htmlspecialchars($t['avatar'] ?: substr($t['client_name'], 0, 2)) ?>
                                </div>
                                <div>
                                    <h5 class="font-bold text-slate-800"><?= htmlspecialchars($t['client_name']) ?></h5>
                                    <span class="text-[10px] text-slate-400"><?= htmlspecialchars($t['client_role']) ?> <?= !empty($t['company']) ? '&bull; ' . htmlspecialchars($t['company']) : '' ?></span>
                                </div>
                            </div>

                            <div class="flex items-center gap-1">
                                <a href="<?= base_url('admin/testimonials.php?edit=' . $t['id']) ?>" class="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                                <form action="<?= base_url('admin/testimonials.php') ?>" method="POST" class="inline" onsubmit="return confirm('Hapus ulasan ini?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $t['id'] ?>">
                                    <button type="submit" class="p-1.5 text-red-500 hover:bg-red-50 rounded-lg">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
