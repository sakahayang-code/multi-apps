<?php
/**
 * MultiApps Solutions - Admin Orders & Inquiries Management
 */

$page_title = 'Pesanan & Permintaan Klien';
$page_subtitle = 'Pantau, tindak lanjuti, dan ubah status konsultasi atau pesanan masuk';

require_once __DIR__ . '/layout/header.php';

$pdo = get_db();

// Handle Export to CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=inquiries_' . date('Ymd_His') . '.csv');
    $output = fopen('php://output', 'w');
    // BOM for Indonesian Excel
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($output, ['No. Tiket', 'Tanggal', 'Nama Pelanggan', 'WhatsApp/Telepon', 'Email', 'Perusahaan', 'Aplikasi Diminta', 'Budget', 'Pesan Klien', 'Status', 'Catatan Admin']);

    $stmt = $pdo->query("SELECT invoice_code, created_at, customer_name, customer_phone, customer_email, company, app_name, budget, message, status, admin_notes FROM inquiries ORDER BY created_at DESC");
    while ($row = $stmt->fetch()) {
        fputcsv($output, [
            $row['invoice_code'],
            $row['created_at'],
            $row['customer_name'],
            $row['customer_phone'],
            $row['customer_email'],
            $row['company'],
            $row['app_name'],
            $row['budget'],
            $row['message'],
            $row['status'],
            $row['admin_notes']
        ]);
    }
    fclose($output);
    exit;
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        set_flash('error', 'Token CSRF tidak valid.');
        header('Location: ' . base_url('admin/inquiries.php'));
        exit;
    }

    // Update Status & Notes
    if ($action === 'update_status') {
        $id = (int)$_POST['id'];
        $status = clean_input($_POST['status'] ?? 'Baru');
        $notes = clean_input($_POST['admin_notes'] ?? '');

        $stmt = $pdo->prepare("UPDATE inquiries SET status = ?, admin_notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$status, $notes, $id]);
        set_flash('success', 'Status pesanan dan catatan admin berhasil diperbarui.');
        header('Location: ' . base_url('admin/inquiries.php'));
        exit;
    }

    // Delete single
    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM inquiries WHERE id = ?")->execute([$id]);
        set_flash('info', 'Permintaan berhasil dihapus.');
        header('Location: ' . base_url('admin/inquiries.php'));
        exit;
    }

    // Bulk Delete Cancelled
    if ($action === 'clear_cancelled') {
        $pdo->exec("DELETE FROM inquiries WHERE status = 'Dibatalkan'");
        set_flash('info', 'Semua riwayat pesanan dengan status "Dibatalkan" telah dibersihkan.');
        header('Location: ' . base_url('admin/inquiries.php'));
        exit;
    }
}

// Filters
$status_filter = clean_input($_GET['status'] ?? 'Semua');
$search_query = clean_input($_GET['q'] ?? '');

$sql = "SELECT * FROM inquiries WHERE 1=1";
$params = [];

if ($status_filter !== 'Semua') {
    $sql .= " AND status = ?";
    $params[] = $status_filter;
}

if (!empty($search_query)) {
    $sql .= " AND (customer_name LIKE ? OR invoice_code LIKE ? OR customer_phone LIKE ? OR app_name LIKE ?)";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
    $params[] = "%$search_query%";
}

$sql .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$inquiries = $stmt->fetchAll();

// Counts per status
$count_all = $pdo->query("SELECT COUNT(*) FROM inquiries")->fetchColumn();
$count_baru = $pdo->query("SELECT COUNT(*) FROM inquiries WHERE status = 'Baru'")->fetchColumn();
$count_proses = $pdo->query("SELECT COUNT(*) FROM inquiries WHERE status = 'Diproses'")->fetchColumn();
$count_selesai = $pdo->query("SELECT COUNT(*) FROM inquiries WHERE status = 'Selesai'")->fetchColumn();
$count_batal = $pdo->query("SELECT COUNT(*) FROM inquiries WHERE status = 'Dibatalkan'")->fetchColumn();
?>

<div class="space-y-6">
    <!-- Filter Tabs & Actions -->
    <div class="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <!-- Status Tabs -->
        <div class="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
            <a href="<?= base_url('admin/inquiries.php?status=Semua') ?>" class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $status_filter === 'Semua' ? 'bg-blue-600 text-white shadow-sm' : 'bg-slate-100 text-slate-600 hover:bg-slate-200' ?>">
                Semua (<?= $count_all ?>)
            </a>
            <a href="<?= base_url('admin/inquiries.php?status=Baru') ?>" class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 <?= $status_filter === 'Baru' ? 'bg-amber-500 text-white shadow-sm' : 'bg-amber-50 text-amber-700 hover:bg-amber-100' ?>">
                <span>Baru</span>
                <span class="bg-amber-600/30 text-[10px] px-1.5 py-0.2 rounded-full"><?= $count_baru ?></span>
            </a>
            <a href="<?= base_url('admin/inquiries.php?status=Diproses') ?>" class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $status_filter === 'Diproses' ? 'bg-blue-600 text-white shadow-sm' : 'bg-blue-50 text-blue-700 hover:bg-blue-100' ?>">
                Diproses (<?= $count_proses ?>)
            </a>
            <a href="<?= base_url('admin/inquiries.php?status=Selesai') ?>" class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $status_filter === 'Selesai' ? 'bg-emerald-600 text-white shadow-sm' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100' ?>">
                Selesai (<?= $count_selesai ?>)
            </a>
            <a href="<?= base_url('admin/inquiries.php?status=Dibatalkan') ?>" class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all <?= $status_filter === 'Dibatalkan' ? 'bg-slate-700 text-white shadow-sm' : 'bg-slate-100 text-slate-500 hover:bg-slate-200' ?>">
                Batal (<?= $count_batal ?>)
            </a>
        </div>

        <!-- Export & Tools -->
        <div class="flex items-center gap-2 w-full md:w-auto justify-end">
            <a href="<?= base_url('admin/inquiries.php?export=csv') ?>" class="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors">
                <i class="fa-solid fa-file-csv text-emerald-600"></i>
                <span>Ekspor CSV</span>
            </a>
            <?php if ($count_batal > 0): ?>
                <form action="<?= base_url('admin/inquiries.php') ?>" method="POST" onsubmit="return confirm('Hapus semua pesanan yang dibatalkan?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="clear_cancelled">
                    <button type="submit" class="px-3 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 font-semibold text-xs transition-colors">
                        Bersihkan Batal
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Search Form -->
    <div class="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm">
        <form action="" method="GET" class="flex gap-2">
            <input type="hidden" name="status" value="<?= htmlspecialchars($status_filter) ?>">
            <div class="relative flex-1">
                <i class="fa-solid fa-search absolute left-3.5 top-3 text-slate-400 text-xs"></i>
                <input type="text" name="q" value="<?= htmlspecialchars($search_query) ?>" placeholder="Cari nama pelanggan, no whatsapp, kode tiket, atau aplikasi..." class="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>
            <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold">
                Cari
            </button>
            <?php if (!empty($search_query)): ?>
                <a href="<?= base_url('admin/inquiries.php?status=' . urlencode($status_filter)) ?>" class="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl text-xs font-semibold flex items-center">
                    Reset
                </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Inquiry Cards List -->
    <?php if (empty($inquiries)): ?>
        <div class="bg-white rounded-3xl border border-slate-200/80 p-12 text-center text-slate-400 text-xs">
            <i class="fa-solid fa-inbox text-5xl text-slate-300 mb-3 block"></i>
            <h4 class="text-base font-bold text-slate-700">Tidak Ada Pesanan Ditemukan</h4>
            <p class="mt-1">Belum ada inquiry yang cocok dengan filter yang dipilih.</p>
        </div>
    <?php else: ?>
        <div class="space-y-4">
            <?php foreach ($inquiries as $inq): ?>
                <?php
                $wa_message = "Halo {$inq['customer_name']},\n\nTerima kasih telah menghubungi MultiApps Solutions mengenai pemesanan/konsultasi *{$inq['app_name']}* dengan nomor tiket *{$inq['invoice_code']}*.\n\nBagaimana kami dapat membantu bisnis Anda lebih lanjut?";
                $wa_url = generate_wa_url($inq['customer_phone'], $wa_message);
                ?>
                <div class="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-sm transition-all hover:border-blue-200 space-y-4">
                    <!-- Header Bar -->
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                        <div class="flex items-center gap-3">
                            <span class="px-3 py-1 rounded-full font-mono text-xs font-bold bg-slate-100 text-slate-700 border border-slate-200">
                                <?= htmlspecialchars($inq['invoice_code']) ?>
                            </span>
                            <span class="text-xs text-slate-400 flex items-center gap-1">
                                <i class="fa-regular fa-clock"></i> <?= date('d M Y, H:i', strtotime($inq['created_at'])) ?> (<?= time_ago($inq['created_at']) ?>)
                            </span>
                        </div>

                        <!-- Status Badge -->
                        <div>
                            <?php
                            $badge = 'bg-slate-100 text-slate-700';
                            if ($inq['status'] === 'Baru') $badge = 'bg-amber-100 text-amber-800 border-amber-200';
                            elseif ($inq['status'] === 'Diproses') $badge = 'bg-blue-100 text-blue-800 border-blue-200';
                            elseif ($inq['status'] === 'Selesai') $badge = 'bg-emerald-100 text-emerald-800 border-emerald-200';
                            elseif ($inq['status'] === 'Dibatalkan') $badge = 'bg-red-100 text-red-800 border-red-200';
                            ?>
                            <span class="px-3 py-1 rounded-full text-xs font-bold border <?= $badge ?>">
                                Status: <?= htmlspecialchars($inq['status']) ?>
                            </span>
                        </div>
                    </div>

                    <!-- Client & Request Info Grid -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                        <!-- Col 1: Customer Info -->
                        <div>
                            <span class="text-[10px] uppercase font-bold text-slate-400 block mb-1">Informasi Pemesan</span>
                            <h4 class="font-bold text-slate-800 text-sm"><?= htmlspecialchars($inq['customer_name']) ?></h4>
                            <?php if (!empty($inq['company'])): ?>
                                <p class="text-slate-500 font-medium"><?= htmlspecialchars($inq['company']) ?></p>
                            <?php endif; ?>
                            
                            <div class="mt-2 space-y-1 text-slate-600">
                                <p class="flex items-center gap-2">
                                    <i class="fa-brands fa-whatsapp text-emerald-500 text-sm w-4"></i>
                                    <span class="font-mono"><?= htmlspecialchars($inq['customer_phone']) ?></span>
                                </p>
                                <?php if (!empty($inq['customer_email'])): ?>
                                    <p class="flex items-center gap-2">
                                        <i class="fa-solid fa-envelope text-blue-500 text-sm w-4"></i>
                                        <span><?= htmlspecialchars($inq['customer_email']) ?></span>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Col 2: App & Budget -->
                        <div>
                            <span class="text-[10px] uppercase font-bold text-slate-400 block mb-1">Aplikasi Terpilih</span>
                            <div class="p-3 bg-blue-50/60 rounded-2xl border border-blue-100">
                                <h5 class="font-bold text-blue-900"><?= htmlspecialchars($inq['app_name']) ?></h5>
                                <?php if (!empty($inq['budget'])): ?>
                                    <p class="text-slate-600 mt-1">Estimasi Budget: <strong class="text-blue-700"><?= htmlspecialchars($inq['budget']) ?></strong></p>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Col 3: Message / Spesifikasi -->
                        <div>
                            <span class="text-[10px] uppercase font-bold text-slate-400 block mb-1">Pesan / Spesifikasi Kebutuhan</span>
                            <div class="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-slate-700 italic leading-relaxed">
                                "<?= nl2br(htmlspecialchars($inq['message'])) ?>"
                            </div>
                        </div>
                    </div>

                    <!-- Action Bar & Notes Update Form -->
                    <div class="pt-3 border-t border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <!-- Update Status Form -->
                        <form action="<?= base_url('admin/inquiries.php') ?>" method="POST" class="flex flex-wrap items-center gap-2 flex-1 text-xs">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="id" value="<?= $inq['id'] ?>">

                            <span class="font-semibold text-slate-600">Ubah Status:</span>
                            <select name="status" class="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white font-semibold text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                <option value="Baru" <?= $inq['status'] === 'Baru' ? 'selected' : '' ?>>Baru</option>
                                <option value="Diproses" <?= $inq['status'] === 'Diproses' ? 'selected' : '' ?>>Diproses</option>
                                <option value="Selesai" <?= $inq['status'] === 'Selesai' ? 'selected' : '' ?>>Selesai</option>
                                <option value="Dibatalkan" <?= $inq['status'] === 'Dibatalkan' ? 'selected' : '' ?>>Dibatalkan</option>
                            </select>

                            <input type="text" name="admin_notes" value="<?= htmlspecialchars($inq['admin_notes']) ?>" placeholder="Catatan internal pengelola..." class="flex-1 min-w-[200px] px-3 py-1.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500 focus:outline-none text-xs">

                            <button type="submit" class="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-semibold rounded-lg transition-colors">
                                Simpan Status
                            </button>
                        </form>

                        <!-- Direct WhatsApp & Delete -->
                        <div class="flex items-center gap-2">
                            <a href="<?= $wa_url ?>" target="_blank" class="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all">
                                <i class="fa-brands fa-whatsapp text-sm"></i>
                                <span>Balas via WhatsApp</span>
                            </a>

                            <form action="<?= base_url('admin/inquiries.php') ?>" method="POST" onsubmit="return confirm('Hapus inquiry ini?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $inq['id'] ?>">
                                <button type="submit" class="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors" title="Hapus">
                                    <i class="fa-solid fa-trash-can"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
