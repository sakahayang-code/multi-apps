<?php
/**
 * MultiApps Solutions - Admin Login Page
 */

require_once __DIR__ . '/../includes/auth.php';

// Redirect if already logged in
if (is_logged_in()) {
    header('Location: ' . base_url('admin/index.php'));
    exit;
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean_input($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error_message = 'Validasi keamanan (CSRF) gagal. Silakan coba lagi.';
    } elseif (empty($username) || empty($password)) {
        $error_message = 'Username dan password wajib diisi.';
    } else {
        if (login_user($username, $password)) {
            $redirect = $_SESSION['redirect_after_login'] ?? base_url('admin/index.php');
            unset($_SESSION['redirect_after_login']);
            header('Location: ' . $redirect);
            exit;
        } else {
            $error_message = 'Username atau kata sandi tidak cocok. Silakan periksa kembali.';
        }
    }
}

$site_title = get_setting('site_title', 'MultiApps Solutions');
$login_logo = get_site_logo();
$login_favicon = get_site_favicon();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk Panel Admin - <?= htmlspecialchars($site_title) ?></title>

    <!-- Favicon (Terkoneksi Otomatis dengan Logo Website) -->
    <?php if (!empty($login_favicon)): ?>
        <link rel="icon" href="<?= htmlspecialchars($login_favicon) ?>">
        <link rel="shortcut icon" href="<?= htmlspecialchars($login_favicon) ?>">
        <link rel="apple-touch-icon" href="<?= htmlspecialchars($login_favicon) ?>">
    <?php endif; ?>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 min-h-screen flex items-center justify-center p-4">

    <div class="max-w-md w-full">
        <!-- Logo & Brand Header -->
        <div class="text-center mb-8">
            <?php if (!empty($login_logo)): ?>
                <img src="<?= htmlspecialchars($login_logo) ?>" alt="<?= htmlspecialchars($site_title) ?>" class="inline-block w-16 h-16 rounded-2xl object-contain bg-white/10 p-2 shadow-xl mb-4 border border-white/10">
            <?php else: ?>
                <div class="inline-flex w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 items-center justify-center text-white shadow-xl shadow-blue-500/20 mb-4">
                    <i class="fa-solid fa-cubes text-3xl"></i>
                </div>
            <?php endif; ?>
            <h1 class="text-2xl font-bold text-white tracking-tight"><?= htmlspecialchars($site_title) ?></h1>
            <p class="text-slate-400 text-xs mt-1">Akses Masuk Panel Pengelola Sistem</p>
        </div>

        <!-- Login Card -->
        <div class="bg-white rounded-3xl p-8 shadow-2xl border border-slate-100">
            <h2 class="text-xl font-bold text-slate-800 mb-2">Selamat Datang Kembali</h2>
            <p class="text-xs text-slate-500 mb-6">Silakan masukkan kredensial akun administrator Anda.</p>

            <?php if (!empty($error_message)): ?>
                <div class="mb-5 p-3.5 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2.5 text-xs text-red-700 font-medium">
                    <i class="fa-solid fa-circle-exclamation text-base flex-shrink-0"></i>
                    <span><?= htmlspecialchars($error_message) ?></span>
                </div>
            <?php endif; ?>

            <form action="" method="POST" class="space-y-4">
                <?= csrf_field() ?>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1.5">Username / Email</label>
                    <div class="relative">
                        <i class="fa-solid fa-user absolute left-3.5 top-3.5 text-slate-400 text-sm"></i>
                        <input type="text" name="username" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" placeholder="" class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-700 mb-1.5">Kata Sandi</label>
                    <div class="relative">
                        <i class="fa-solid fa-lock absolute left-3.5 top-3.5 text-slate-400 text-sm"></i>
                        <input type="password" name="password" id="password-input" required placeholder="" class="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all">
                        <button type="button" onclick="togglePasswordVisibility()" class="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600">
                            <i id="password-toggle-icon" class="fa-solid fa-eye text-sm"></i>
                        </button>
                    </div>
                </div>

                <div class="pt-2">
                    <button type="submit" class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl text-sm shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center gap-2">
                        <i class="fa-solid fa-right-to-bracket"></i>
                        <span>Masuk ke Panel Admin</span>
                    </button>
                </div>
            </form>

            <div class="mt-6 pt-5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <a href="<?= base_url() ?>" class="hover:text-blue-600 transition-colors flex items-center gap-1.5">
                    <i class="fa-solid fa-arrow-left"></i> Kembali ke Beranda
                </a>
                <span class="text-slate-400">Database: SQLite 3</span>
            </div>
        </div>

        <!-- Demo Credentials Hint (Helpful for first-time setup) -->
        <div class="mt-6 text-center text-xs text-slate-400 bg-slate-800/60 p-4 rounded-2xl border border-slate-700/50 backdrop-blur-sm">
            <p class="font-semibold text-slate-300 mb-1"><i class="fa-solid fa-key text-amber-400 mr-1"></i> Akun Bawaan (Default):</p>
            <p>Username: <code class="text-blue-400 bg-slate-900 px-1.5 py-0.5 rounded">admin</code> | Sandi: <code class="text-blue-400 bg-slate-900 px-1.5 py-0.5 rounded">admin123</code></p>
            <p class="text-[11px] text-slate-500 mt-1">Anda dapat mengubah password ini di menu Pengaturan Website.</p>
        </div>
    </div>

    <script>
        function togglePasswordVisibility() {
            const input = document.getElementById('password-input');
            const icon = document.getElementById('password-toggle-icon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
