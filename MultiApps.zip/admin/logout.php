<?php
/**
 * MultiApps Solutions - Admin Logout Handler
 */

require_once __DIR__ . '/../includes/auth.php';

logout_user();
set_flash('info', 'Anda telah berhasil keluar dari sistem pengelola.');
header('Location: ' . base_url('admin/login.php'));
exit;
