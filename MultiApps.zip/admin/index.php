<?php
/**
 * MultiApps Solutions - Admin Dashboard
 */

$page_title = 'Dashboard Utama';
$page_subtitle = 'Ringkasan statistik katalog, pesanan masuk, dan kesehatan sistem';

require_once __DIR__ . '/layout/header.php';

$pdo = get_db();

// Counts
$count_apps = $pdo->query("SELECT COUNT(*) FROM apps")->fetchColumn();
$count_categories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$count_inquiries = $pdo->query("SELECT COUNT(*) FROM inquiries")->fetchColumn();
$count_pending = $pdo->query("SELECT COUNT(*) FROM inquiries WHERE status = 'Baru'")->fetchColumn();
$count_testimonials = $pdo->query("SELECT COUNT(*) FROM testimonials")->fetchColumn();

// Recent Inquiries
$recent_inquiries = $pdo->query("SELECT * FROM inquiries ORDER BY created_at DESC LIMIT 5")->fetchAll();

// Featured Apps
$featured_apps = $pdo->query("SELECT a.*, c.name as category_name FROM apps a LEFT JOIN categories c ON a.category_id = c.id WHERE a.is_featured = 1 ORDER BY a.id DESC LIMIT 4")->fetchAll();

// DB file size
$db_size_bytes = @filesize(__DIR__ . '/../database/multiapps.sqlite') ?: 0;
$db_size_mb = round($db_size_bytes / (1024 * 1024), 2);
if ($db_size_mb < 0.1) {
    $db_size_text = round($db_size_bytes / 1024, 1) . ' KB';
} else {
    $db_size_text = $db_size_mb . ' MB';
}
?>

<!-- METRICS CARDS -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
    <!-- Card 1 -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm flex items-center justify-between">
        <div>
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Aplikasi</span>
            <h3 class="text-3xl font-extrabold text-slate-900 mt-1"><?= $count_apps ?></h3>
            <a href="<?= base_url('admin/apps.php') ?>" class="text-xs text-blue-600 font-semibold hover:underline inline-flex items-center gap-1 mt-2">
                Kelola Produk <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>
        <div class="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-2xl shadow-sm">
            <i class="fa-solid fa-box-open"></i>
        </div>
    </div>

    <!-- Card 2 -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm flex items-center justify-between">
        <div>
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Pesanan Baru</span>
            <h3 class="text-3xl font-extrabold <?= $count_pending > 0 ? 'text-amber-500' : 'text-slate-900' ?> mt-1"><?= $count_pending ?></h3>
            <a href="<?= base_url('admin/inquiries.php?status=Baru') ?>" class="text-xs text-amber-600 font-semibold hover:underline inline-flex items-center gap-1 mt-2">
                Perlu Tindakan <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>
        <div class="w-14 h-14 rounded-2xl <?= $count_pending > 0 ? 'bg-amber-50 text-amber-500 animate-pulse' : 'bg-slate-50 text-slate-400' ?> flex items-center justify-center text-2xl shadow-sm">
            <i class="fa-solid fa-bell"></i>
        </div>
    </div>

    <!-- Card 3 -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm flex items-center justify-between">
        <div>
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Semua Order</span>
            <h3 class="text-3xl font-extrabold text-slate-900 mt-1"><?= $count_inquiries ?></h3>
            <a href="<?= base_url('admin/inquiries.php') ?>" class="text-xs text-indigo-600 font-semibold hover:underline inline-flex items-center gap-1 mt-2">
                Lihat Riwayat <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>
        <div class="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-2xl shadow-sm">
            <i class="fa-solid fa-file-invoice"></i>
        </div>
    </div>

    <!-- Card 4 -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm flex items-center justify-between">
        <div>
            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Kategori & Review</span>
            <h3 class="text-3xl font-extrabold text-slate-900 mt-1"><?= $count_categories ?> <span class="text-base font-normal text-slate-400">/ <?= $count_testimonials ?></span></h3>
            <a href="<?= base_url('admin/categories.php') ?>" class="text-xs text-emerald-600 font-semibold hover:underline inline-flex items-center gap-1 mt-2">
                Kategori Sistem <i class="fa-solid fa-arrow-right text-[10px]"></i>
            </a>
        </div>
        <div class="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-2xl shadow-sm">
            <i class="fa-solid fa-layer-group"></i>
        </div>
    </div>
</div>

<!-- QUICK ACTION BAR -->
<div class="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-3xl p-6 mb-8 text-white shadow-lg shadow-blue-500/10 flex flex-col sm:flex-row items-center justify-between gap-4">
    <div class="flex items-center gap-4">
        <div class="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-xl text-white">
            <i class="fa-solid fa-bolt"></i>
        </div>
        <div>
            <h4 class="font-bold text-base">Aksi Cepat Pengelola</h4>
            <p class="text-xs text-blue-100">Tambahkan aplikasi baru atau respon permintaan klien secara instan.</p>
        </div>
    </div>
    <div class="flex flex-wrap items-center gap-3 w-full sm:w-auto">
        <a href="<?= base_url('admin/apps.php?action=create') ?>" class="flex-1 sm:flex-none text-center px-4 py-2.5 bg-white text-blue-700 hover:bg-blue-50 font-semibold text-xs rounded-xl shadow transition-all">
            <i class="fa-solid fa-plus mr-1"></i> Tambah Aplikasi
        </a>
        <a href="<?= base_url('admin/inquiries.php') ?>" class="flex-1 sm:flex-none text-center px-4 py-2.5 bg-blue-500/40 hover:bg-blue-500/60 text-white font-semibold text-xs rounded-xl border border-white/20 transition-all">
            <i class="fa-solid fa-inbox mr-1"></i> Semua Pesanan
        </a>
        <a href="<?= base_url('admin/settings.php') ?>" class="flex-1 sm:flex-none text-center px-4 py-2.5 bg-blue-500/40 hover:bg-blue-500/60 text-white font-semibold text-xs rounded-xl border border-white/20 transition-all">
            <i class="fa-solid fa-database mr-1"></i> Backup SQLite
        </a>
    </div>
</div>

<!-- MAIN GRID: RECENT INQUIRIES & SYSTEM HEALTH -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
    <!-- Inquiries Table (2 cols) -->
    <div class="lg:col-span-2 bg-white rounded-3xl border border-slate-200/80 p-6 shadow-sm flex flex-col justify-between">
        <div>
            <div class="flex items-center justify-between mb-5">
                <div>
                    <h3 class="font-bold text-slate-800 text-base">Pesanan & Permintaan Terbaru</h3>
                    <p class="text-xs text-slate-400">5 calon pembeli atau klien yang baru mengirim formulir</p>
                </div>
                <a href="<?= base_url('admin/inquiries.php') ?>" class="text-xs text-blue-600 font-semibold hover:underline">
                    Lihat Semua
                </a>
            </div>

            <?php if (empty($recent_inquiries)): ?>
                <div class="text-center py-12 text-slate-400 text-xs">
                    <i class="fa-solid fa-inbox text-4xl mb-3 text-slate-300"></i>
                    <p>Belum ada pesan atau pesanan masuk.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="border-b border-slate-100 text-slate-400 uppercase tracking-wider text-[10px]">
                                <th class="pb-3 font-semibold">Kode / Klien</th>
                                <th class="pb-3 font-semibold">Aplikasi</th>
                                <th class="pb-3 font-semibold">Status</th>
                                <th class="pb-3 font-semibold text-right">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php foreach ($recent_inquiries as $inq): ?>
                                <tr class="hover:bg-slate-50 transition-colors">
                                    <td class="py-3.5 pr-2">
                                        <span class="font-bold text-slate-800 block"><?= htmlspecialchars($inq['customer_name']) ?></span>
                                        <span class="text-[10px] text-slate-400 font-mono"><?= htmlspecialchars($inq['invoice_code']) ?> &bull; <?= time_ago($inq['created_at']) ?></span>
                                    </td>
                                    <td class="py-3.5 pr-2">
                                        <span class="font-medium text-slate-700 block"><?= htmlspecialchars($inq['app_name']) ?></span>
                                        <span class="text-[10px] text-slate-400"><i class="fa-brands fa-whatsapp text-emerald-500 mr-1"></i><?= htmlspecialchars($inq['customer_phone']) ?></span>
                                    </td>
                                    <td class="py-3.5 pr-2">
                                        <?php
                                        $badge_class = 'bg-slate-100 text-slate-700';
                                        if ($inq['status'] === 'Baru') $badge_class = 'bg-amber-100 text-amber-800 font-bold';
                                        elseif ($inq['status'] === 'Diproses') $badge_class = 'bg-blue-100 text-blue-800 font-bold';
                                        elseif ($inq['status'] === 'Selesai') $badge_class = 'bg-emerald-100 text-emerald-800 font-bold';
                                        elseif ($inq['status'] === 'Dibatalkan') $badge_class = 'bg-red-100 text-red-800';
                                        ?>
                                        <span class="px-2.5 py-1 rounded-full text-[10px] <?= $badge_class ?>">
                                            <?= htmlspecialchars($inq['status']) ?>
                                        </span>
                                    </td>
                                    <td class="py-3.5 text-right whitespace-nowrap">
                                        <?php
                                        $reply_msg = "Halo {$inq['customer_name']}, terima kasih telah menghubungi MultiApps Solutions mengenai {$inq['app_name']} (Tiket: {$inq['invoice_code']}).";
                                        $wa_link = generate_wa_url($inq['customer_phone'], $reply_msg);
                                        ?>
                                        <a href="<?= $wa_link ?>" target="_blank" class="inline-flex items-center gap-1 px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-600 text-emerald-700 hover:text-white rounded-lg font-semibold text-[11px] transition-colors" title="Balas via WhatsApp">
                                            <i class="fa-brands fa-whatsapp"></i> Chat WA
                                        </a>
                                        <a href="<?= base_url('admin/inquiries.php?id=' . $inq['id']) ?>" class="p-1.5 text-slate-400 hover:text-blue-600 inline-block" title="Detail">
                                            <i class="fa-solid fa-chevron-right text-xs"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <div class="pt-4 border-t border-slate-100 text-right">
            <a href="<?= base_url('admin/inquiries.php') ?>" class="text-xs font-semibold text-blue-600 hover:text-blue-700">
                Kelola Semua Pesanan Masuk &rarr;
            </a>
        </div>
    </div>

    <!-- System & Hosting Card (1 col) -->
    <div class="space-y-6">
        <!-- Hosting Status -->
        <div class="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-sm">
            <h4 class="font-bold text-slate-800 text-sm mb-4 flex items-center gap-2">
                <i class="fa-solid fa-server text-blue-600"></i> Status Lingkungan Hosting
            </h4>
            
            <div class="space-y-3 text-xs">
                <div class="flex justify-between py-2 border-b border-slate-100">
                    <span class="text-slate-500">Tipe Database:</span>
                    <span class="font-semibold text-slate-800 flex items-center gap-1">
                        <i class="fa-solid fa-database text-blue-500"></i> SQLite 3 (WAL Mode)
                    </span>
                </div>
                <div class="flex justify-between py-2 border-b border-slate-100">
                    <span class="text-slate-500">Ukuran File DB:</span>
                    <span class="font-semibold text-slate-800"><?= $db_size_text ?></span>
                </div>
                <div class="flex justify-between py-2 border-b border-slate-100">
                    <span class="text-slate-500">Versi PHP:</span>
                    <span class="font-semibold text-emerald-600"><?= phpversion() ?></span>
                </div>
                <div class="flex justify-between py-2 border-b border-slate-100">
                    <span class="text-slate-500">Target Hosting:</span>
                    <span class="font-semibold text-indigo-600">Rumahweb / cPanel Ready</span>
                </div>
                <div class="flex justify-between py-2">
                    <span class="text-slate-500">Status Keamanan:</span>
                    <span class="font-semibold text-emerald-600 flex items-center gap-1">
                        <i class="fa-solid fa-shield-check"></i> .htaccess Proteksi Aktif
                    </span>
                </div>
            </div>

            <div class="mt-5 pt-4 border-t border-slate-100">
                <a href="<?= base_url('admin/settings.php') ?>" class="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors">
                    <i class="fa-solid fa-download"></i> Unduh File Backup SQLite
                </a>
            </div>
        </div>

        <!-- Catalog Highlights -->
        <div class="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h4 class="font-bold text-slate-800 text-sm">Aplikasi Unggulan</h4>
                <a href="<?= base_url('admin/apps.php?featured=1') ?>" class="text-[11px] text-blue-600 hover:underline">Kelola</a>
            </div>

            <div class="space-y-3">
                <?php foreach ($featured_apps as $fapp): ?>
                    <div class="flex items-center gap-3">
                        <img src="<?= htmlspecialchars($fapp['image'] ?: 'https://placehold.co/100x100/0284c7/white?text=App') ?>" class="w-10 h-10 rounded-xl object-cover border border-slate-200 flex-shrink-0">
                        <div class="overflow-hidden flex-1">
                            <h5 class="font-semibold text-xs text-slate-800 truncate"><?= htmlspecialchars($fapp['title']) ?></h5>
                            <span class="text-[10px] text-blue-600 font-bold"><?= format_rupiah($fapp['price']) ?></span>
                        </div>
                        <span class="text-amber-500 text-xs"><i class="fa-solid fa-star"></i></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
