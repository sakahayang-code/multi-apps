# MultiApps Solutions

Platform Katalog Aplikasi & Sistem Digital Modern berbasis **PHP murni** dan database **SQLite 3**, dirancang khusus untuk deployment instan di hosting cPanel seperti **Rumahweb Indonesia** maupun server lokal (Laragon / XAMPP).

## Fitur Utama

- **Database SQLite Mandiri (Auto-Migration & Seeding):** Tidak memerlukan instalasi database MySQL manual.
- **Frontend Interaktif & Responsif:**
  - Hero dengan pencarian live & tag populer
  - Statistik dinamis
  - Filter kategori & pengurutan katalog (Termurah, Termahal, Unggulan, A-Z)
  - Modal detail aplikasi dengan fitur checklist dan live demo
  - Pemesanan terintegrasi langsung dengan database dan WhatsApp
  - Pelacakan status tiket / pesanan publik (*Order Tracking*)
  - Testimoni dan Accordion FAQ interaktif
  - Tombol melayang WhatsApp
- **Panel Pengelola (Admin Dashboard):**
  - Autentikasi aman (`password_hash` & CSRF Protection)
  - Dashboard analitik & kesehatan database
  - CRUD Portofolio Aplikasi + Upload Gambar & Featured Toggle
  - CRUD Kategori dengan ikon FontAwesome
  - Manajemen Pesanan Masuk (Ubah status, Catatan admin, 1-Click WhatsApp Reply, Ekspor CSV)
  - Manajemen Testimoni & FAQ
  - **Upload Logo & Favicon Otomatis:** Logo yang diunggah otomatis terkoneksi menjadi favicon tab browser, logo navbar publik, dan logo panel admin.
  - Pengaturan Identitas Website & Kontak WhatsApp
  - 1-Klik Download Backup Database SQLite & Optimasi VACUUM
- **Keamanan Server:**
  - Proteksi `.htaccess` untuk mengunci file `.sqlite` dan file sensitif dari akses browser luar.

## Panduan Hosting Rumahweb

Silakan baca file lengkap [PANDUAN_HOSTING_RUMAHWEB.md](PANDUAN_HOSTING_RUMAHWEB.md) untuk instruksi langkah demi langkah mengunggah ke cPanel Rumahweb.

## Login Admin Bawaan (Default)
- **URL Admin:** `/admin/login.php`
- **Username:** `admin`
- **Password:** `admin123`
*(Dapat diubah di menu Pengaturan Website)*
