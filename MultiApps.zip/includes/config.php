<?php
/**
 * MultiApps Solutions - Application Configuration & Helpers
 */

if (!defined('MULTITAPPS_APP')) {
    define('MULTITAPPS_APP', true);
}

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Error reporting for production/development
// On hosting Rumahweb, errors can be logged rather than exposed
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Include Database connection
require_once __DIR__ . '/../database/db.php';

// Detect Base URL dynamically
function base_url($path = '') {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)) ? "https://" : "http://";
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    
    // Determine the root directory relative to DOCUMENT_ROOT
    $script_raw = $_SERVER['SCRIPT_NAME'] ?? '';
    $script_dir = str_replace('\\', '/', dirname($script_raw));
    if ($script_dir === '.' || $script_dir === '/' || empty($script_dir)) {
        $base_dir = '';
    } else {
        $base_dir = preg_replace('#/(admin|api|database|includes).*$#', '', $script_dir);
        $base_dir = rtrim($base_dir, '/');
    }
    
    $url = $protocol . $host . $base_dir;
    if ($path) {
        $url .= '/' . ltrim($path, '/');
    }
    return $url;
}

// CSRF Token Management
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string)$token);
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(generate_csrf_token()) . '">';
}

// Input Sanitization
function clean_input($data) {
    if (is_array($data)) {
        return array_map('clean_input', $data);
    }
    return htmlspecialchars(trim((string)$data), ENT_QUOTES, 'UTF-8');
}

// Currency Formatter
function format_rupiah($number) {
    if ($number === null || $number === '' || $number == 0) {
        return 'Hubungi Kami';
    }
    return 'Rp ' . number_format((float)$number, 0, ',', '.');
}

// Slug generator
function slugify($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    return empty($text) ? 'app-' . time() : $text;
}

// WhatsApp URL generator
function generate_wa_url($phone, $message = '') {
    // Clean phone number: remove +, space, dash
    $clean_phone = preg_replace('/[^0-9]/', '', (string)$phone);
    if (substr($clean_phone, 0, 1) === '0') {
        $clean_phone = '62' . substr($clean_phone, 1);
    } elseif (substr($clean_phone, 0, 2) !== '62') {
        $clean_phone = '62' . $clean_phone;
    }
    
    $url = "https://wa.me/" . $clean_phone;
    if (!empty($message)) {
        $url .= "?text=" . urlencode($message);
    }
    return $url;
}

// Flash Message System
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'error', 'info', 'warning'
        'message' => $message
    ];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// Time elapsed string in Indonesian
function time_ago($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60) return 'Baru saja';
    if ($diff < 3600) return floor($diff / 60) . ' menit yang lalu';
    if ($diff < 86400) return floor($diff / 3600) . ' jam yang lalu';
    if ($diff < 604800) return floor($diff / 86400) . ' hari yang lalu';
    return date('d M Y, H:i', $time);
}

// Logo & Favicon Helpers
function get_site_logo() {
    $logo = get_setting('site_logo', '');
    if (!empty($logo)) {
        if (strpos($logo, 'http') === 0) {
            return $logo;
        }
        return base_url($logo);
    }
    return '';
}

function get_site_favicon() {
    return get_site_logo();
}
