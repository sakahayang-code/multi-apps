<?php
/**
 * MultiApps Solutions - Database Connection & SQLite Auto-Migrator
 * Compatible with Rumahweb Hosting & Localhost
 */

if (!defined('MULTITAPPS_APP')) {
    define('MULTITAPPS_APP', true);
}

// Path to SQLite Database file
$db_dir = __DIR__;
$db_file = $db_dir . DIRECTORY_SEPARATOR . 'multiapps.sqlite';

if (!file_exists($db_dir)) {
    @mkdir($db_dir, 0755, true);
}

// Function to establish PDO Connection
function get_db() {
    global $db_file;
    static $pdo = null;

    if ($pdo === null) {
        try {
            $is_new_db = !file_exists($db_file);
            $pdo = new PDO("sqlite:" . $db_file);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            // Performance and safety pragmas
            $pdo->exec("PRAGMA journal_mode = WAL;");
            $pdo->exec("PRAGMA foreign_keys = ON;");

            // Initialize schema if newly created or missing tables
            initialize_database($pdo, $is_new_db);

        } catch (PDOException $e) {
            die("<strong>Database Connection Error:</strong> " . htmlspecialchars($e->getMessage()) . "<br>Pastikan folder <code>database/</code> memiliki hak akses tulis (permissions 755/777) di hosting Rumahweb Anda.");
        }
    }

    return $pdo;
}

// Function to initialize tables and initial seed data
function initialize_database($pdo, $is_new_db = false) {
    // Check if admins table exists
    $stmt = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='admins'");
    $tables_exist = $stmt->fetch();

    if (!$tables_exist) {
        // Create Admins Table
        $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            avatar TEXT DEFAULT '',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // Create Settings Table
        $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            setting_key TEXT UNIQUE NOT NULL,
            setting_value TEXT
        )");

        // Create Categories Table
        $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            slug TEXT NOT NULL UNIQUE,
            icon TEXT DEFAULT 'fa-layer-group',
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // Create Apps Table
        $pdo->exec("CREATE TABLE IF NOT EXISTS apps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            slug TEXT NOT NULL UNIQUE,
            category_id INTEGER NOT NULL,
            price REAL DEFAULT 0,
            price_label TEXT DEFAULT 'Mulai dari',
            image TEXT DEFAULT '',
            description TEXT,
            full_description TEXT,
            features TEXT,
            tech_stack TEXT DEFAULT 'PHP, Tailwind, SQLite, MySQL',
            platform TEXT DEFAULT 'Web & Mobile',
            version TEXT DEFAULT 'v1.0.0',
            license TEXT DEFAULT 'Lisensi Seumur Hidup',
            demo_url TEXT DEFAULT '',
            is_featured INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            views_count INTEGER DEFAULT 0,
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
        )");

        // Create Inquiries / Orders Table
        $pdo->exec("CREATE TABLE IF NOT EXISTS inquiries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_code TEXT UNIQUE NOT NULL,
            app_id INTEGER DEFAULT NULL,
            app_name TEXT NOT NULL,
            customer_name TEXT NOT NULL,
            customer_phone TEXT NOT NULL,
            customer_email TEXT DEFAULT '',
            company TEXT DEFAULT '',
            message TEXT NOT NULL,
            budget TEXT DEFAULT '',
            status TEXT DEFAULT 'Baru', -- 'Baru', 'Diproses', 'Selesai', 'Dibatalkan'
            admin_notes TEXT DEFAULT '',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // Create Testimonials Table
        $pdo->exec("CREATE TABLE IF NOT EXISTS testimonials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT NOT NULL,
            client_role TEXT NOT NULL,
            company TEXT DEFAULT '',
            avatar TEXT DEFAULT '',
            review TEXT NOT NULL,
            rating INTEGER DEFAULT 5,
            is_active INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // Create FAQs Table
        $pdo->exec("CREATE TABLE IF NOT EXISTS faqs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            sort_order INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // Seed initial default data
        seed_default_data($pdo);
    }
}

// Function to populate default data
function seed_default_data($pdo) {
    // 1. Seed Admin: username: admin / password: password123
    $default_password_hash = password_hash('admin123', PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO admins (username, password, name, email) VALUES (?, ?, ?, ?)");
    $stmt->execute(['admin', $default_password_hash, 'Administrator MultiApps', 'admin@multiapps.id']);

    // 2. Seed Settings
    $default_settings = [
        'site_title' => 'MultiApps Solutions',
        'site_tagline' => 'Katalog Aplikasi Modern & Solusi Digital Indonesia',
        'hero_title' => 'Solusi Software & Aplikasi Sistem untuk Pertumbuhan Bisnis Anda',
        'hero_subtitle' => 'Temukan ratusan opsi aplikasi siap pakai, sistem custom enterprise, hingga web app modern yang disesuaikan dengan kebutuhan bisnis skala kecil hingga besar.',
        'hero_badge' => 'Penyedia Sistem & Software Terlengkap',
        'contact_email' => 'support@multiapps.id',
        'contact_phone' => '+62 812-3456-7890',
        'contact_whatsapp' => '6281234567890',
        'contact_address' => 'Jakarta Tech Park, Tower A Lantai 8, Jakarta Selatan',
        'whatsapp_greeting' => 'Halo MultiApps Solutions, saya ingin konsultasi mengenai aplikasi: ',
        'facebook_url' => 'https://facebook.com',
        'instagram_url' => 'https://instagram.com',
        'linkedin_url' => 'https://linkedin.com',
        'github_url' => 'https://github.com',
        'meta_description' => 'MultiApps Solutions - Penyedia sistem aplikasi kasir POS, ERP HRIS, E-Commerce, SIMRS, dan sistem sekolah terpercaya di Indonesia.',
        'stat_clients' => '500+',
        'stat_uptime' => '99.9%',
        'stat_support' => '24/7'
    ];

    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)");
    foreach ($default_settings as $key => $val) {
        $stmt->execute([$key, $val]);
    }

    // 3. Seed Categories
    $categories = [
        ['name' => 'POS & Kasir', 'slug' => 'pos-kasir', 'icon' => 'fa-cash-register', 'sort' => 1],
        ['name' => 'ERP & HRIS', 'slug' => 'erp-hris', 'icon' => 'fa-users-gear', 'sort' => 2],
        ['name' => 'E-Commerce', 'slug' => 'e-commerce', 'icon' => 'fa-cart-shopping', 'sort' => 3],
        ['name' => 'Manajemen Rumah Sakit', 'slug' => 'manajemen-rumah-sakit', 'icon' => 'fa-hospital-user', 'sort' => 4],
        ['name' => 'Sistem Sekolah', 'slug' => 'sistem-sekolah', 'icon' => 'fa-graduation-cap', 'sort' => 5],
        ['name' => 'Fintech & Keuangan', 'slug' => 'fintech-keuangan', 'icon' => 'fa-wallet', 'sort' => 6],
        ['name' => 'Logistik & Ekspedisi', 'slug' => 'logistik-ekspedisi', 'icon' => 'fa-truck-fast', 'sort' => 7]
    ];

    $cat_stmt = $pdo->prepare("INSERT INTO categories (name, slug, icon, sort_order) VALUES (?, ?, ?, ?)");
    $cat_ids = [];
    foreach ($categories as $cat) {
        $cat_stmt->execute([$cat['name'], $cat['slug'], $cat['icon'], $cat['sort']]);
        $cat_ids[$cat['name']] = $pdo->lastInsertId();
    }

    // 4. Seed Apps
    $apps = [
        [
            'title' => 'Smart POS Resto Pro',
            'slug' => 'smart-pos-resto-pro',
            'category_id' => $cat_ids['POS & Kasir'],
            'price' => 1850000,
            'price_label' => 'Sekali Beli',
            'image' => 'https://images.unsplash.com/photo-1556742049-0a6796d7c766?auto=format&fit=crop&w=700&q=80',
            'description' => 'Sistem Kasir Point of Sales pintar khusus restoran, cafe, dan food court dengan modul manajemen dapur, meja, dan cetak bil terpisah.',
            'full_description' => 'Aplikasi POS Resto dirancang khusus untuk memangkas antrean, mempercepat pesanan antara pelayan dan koki dapur melalui Kitchen Display System (KDS), serta menyajikan laporan omzet harian secara otomatis. Dilengkapi fitur QR Menu di meja pelanggan.',
            'features' => "Integrasi Kitchen Printer Thermal\nSplit Bill & Multi Payment Method\nLaporan Laba Rugi & HPP Otomatis\nManajemen Stok Bahan Baku Realtime\nQR Menu Pesan Mandiri dari Meja",
            'tech_stack' => 'PHP 8, Tailwind CSS, SQLite/MySQL, PWA Ready',
            'platform' => 'Web & Android POS Tablet',
            'version' => 'v3.2.0',
            'license' => 'Lisensi Seumur Hidup (Lifetime)',
            'demo_url' => 'https://pos-demo.multiapps.id',
            'is_featured' => 1,
            'is_active' => 1
        ],
        [
            'title' => 'Omni HRIS & Payroll Cloud',
            'slug' => 'omni-hris-payroll-cloud',
            'category_id' => $cat_ids['ERP & HRIS'],
            'price' => 3500000,
            'price_label' => 'Mulai dari',
            'image' => 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=700&q=80',
            'description' => 'Platform lengkap pengelolaan SDM mencakup absensi GPS online, perhitungan slip gaji otomatis (PPH21/BPJS), dan pengajuan cuti karyawan.',
            'full_description' => 'Sistem Informasi Sumber Daya Manusia (HRIS) terintegrasi dengan validasi absensi menggunakan Face Recognition dan radius GPS. Penggajian otomatis menghasilkan slip gaji PDF dan laporan pajak PPh 21 terbaru.',
            'features' => "Absensi GPS & Anti-Fake GPS Face ID\nKalkulasi Slip Gaji Otomatis (PPh 21 & BPJS)\nManajemen Cuti, Lembur, & Shift Kerja\nPortal Mandiri Karyawan (Self-Service)\nEkspor Laporan Bank Transfer Excel",
            'tech_stack' => 'PHP 8, Bootstrap 5 / Tailwind, SQLite/MySQL',
            'platform' => 'Web App Responsive & Mobile Browser',
            'version' => 'v2.8.5',
            'license' => 'Lisensi Server Perusahaan',
            'demo_url' => 'https://hris-demo.multiapps.id',
            'is_featured' => 1,
            'is_active' => 1
        ],
        [
            'title' => 'StoreFront Multi-Vendor E-Shop',
            'slug' => 'storefront-multi-vendor-eshop',
            'category_id' => $cat_ids['E-Commerce'],
            'price' => 2900000,
            'price_label' => 'Paket Komplit',
            'image' => 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=700&q=80',
            'description' => 'Solusi Marketplace multi-penjual lengkap dengan sistem ongkir otomatis RajaOngkir, payment gateway Midtrans / Xendit, dan bagi hasil komisi.',
            'full_description' => 'Aplikasi toko online modern dengan dukungan toko tunggal maupun multi-seller. Dilengkapi integrasi kurir nasional (JNE, J&T, SiCepat), pembayaran QRIS, Virtual Account, serta notifikasi otomatis ke WhatsApp pelanggan.',
            'features' => "Dukungan Multi-Vendor & Toko Tunggal\nHitung Ongkos Kirim Otomatis (RajaOngkir)\nIntegrasi Payment Gateway QRIS & VA\nNotifikasi Pesanan Otomatis ke WhatsApp\nPanel Dashboard Penjual & Admin Utama",
            'tech_stack' => 'PHP 8, Tailwind CSS, SQLite/MySQL, API Ready',
            'platform' => 'Web Responsive (Mobile-Friendly)',
            'version' => 'v4.1.0',
            'license' => 'Lisensi Seumur Hidup + Full Source Code',
            'demo_url' => 'https://eshop-demo.multiapps.id',
            'is_featured' => 0,
            'is_active' => 1
        ],
        [
            'title' => 'Medika SIMRS & Antrean Klinik',
            'slug' => 'medika-simrs-antrean-klinik',
            'category_id' => $cat_ids['Manajemen Rumah Sakit'],
            'price' => 7500000,
            'price_label' => 'Enterprise',
            'image' => 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&w=700&q=80',
            'description' => 'Sistem Informasi Manajemen Rumah Sakit & Klinik terpadu dari rekam medis elektronik (RME), antrean suara, resep farmasi, hingga kasir.',
            'full_description' => 'Sistem SIMRS standar Permenkes SatuSehat. Mendukung alur registrasi pasien, antrean poli dengan panggilan suara otomatis, input RME dokter, peracikan obat apotek, hingga cetak klaim pembayaran.',
            'features' => "Rekam Medis Elektronik (RME) Standar Kemenkes\nModul Depo Farmasi & Stok Obat ED\nPanggilan Antrean Pasien Berbasis Suara\nIntegrasi Kasir Tindakan Medis & Laboratorium\nLaporan Statistik Morbiditas Pasien",
            'tech_stack' => 'PHP, Tailwind CSS, Alpine.js, SQLite/MySQL',
            'platform' => 'Web Local / Cloud Server',
            'version' => 'v2.1.0',
            'license' => 'Lisensi Klinik / Rumah Sakit',
            'demo_url' => 'https://simrs-demo.multiapps.id',
            'is_featured' => 1,
            'is_active' => 1
        ],
        [
            'title' => 'EduSmart SIAKAD & CBT Sekolah',
            'slug' => 'edusmart-siakad-cbt-sekolah',
            'category_id' => $cat_ids['Sistem Sekolah'],
            'price' => 2200000,
            'price_label' => 'Lisensi Lembaga',
            'image' => 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=700&q=80',
            'description' => 'Aplikasi akademik sekolah terpadu mencakup input e-Rapor Kurikulum Merdeka, tagihan SPP via Payment Gateway, dan ujian online CBT.',
            'full_description' => 'Solusi digitalisasi sekolah dasar, menengah, hingga pesantren. Mencakup manajemen data siswa, guru, jadwal pelajaran, absensi barcode kelas, e-rapor, serta modul Computer Based Test (CBT) anti-curang.',
            'features' => "E-Rapor Kurikulum Merdeka & 2013\nSistem Ujian Online CBT Anti-Minimize\nManajemen Tagihan & Pembayaran SPP Online\nPortal Login Khusus Siswa, Guru, & Wali Murid\nKirim Pengumuman Broadcast ke WhatsApp",
            'tech_stack' => 'PHP 8, Tailwind CSS, SQLite/MySQL',
            'platform' => 'Web Responsive & PWA',
            'version' => 'v3.0.4',
            'license' => 'Lisensi Sekolah / Yayasan',
            'demo_url' => 'https://siakad-demo.multiapps.id',
            'is_featured' => 0,
            'is_active' => 1
        ],
        [
            'title' => 'Koperasi & Micro-Fintech Pro',
            'slug' => 'koperasi-micro-fintech-pro',
            'category_id' => $cat_ids['Fintech & Keuangan'],
            'price' => 3800000,
            'price_label' => 'Mulai dari',
            'image' => 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=700&q=80',
            'description' => 'Aplikasi Simpan Pinjam Koperasi (KSP/BMT) dengan hitungan bunga anuitas, flat, sliding, cetak buku tabungan, dan SHU otomatis.',
            'full_description' => 'Sistem Koperasi Simpan Pinjam modern dengan perhitungan bunga akurat. Mendukung pencetakan buku tabungan, kwitansi angsuran, kolektor mobile collector, serta laporan neraca & laba rugi otomatis.',
            'features' => "Hitung Bunga Flat, Efektif, & Anuitas\nPerhitungan & Pembagian SHU Otomatis\nPencetakan Buku Tabungan & Slip Angsuran\nManajemen Kas & Jurnal Akuntansi Standar SAK ETAP\nAkses Kolektor Lapangan via HP",
            'tech_stack' => 'PHP 8, Tailwind CSS, SQLite/MySQL',
            'platform' => 'Web Application Cloud/Local',
            'version' => 'v2.5.0',
            'license' => 'Lisensi Koperasi Seumur Hidup',
            'demo_url' => 'https://koperasi-demo.multiapps.id',
            'is_featured' => 1,
            'is_active' => 1
        ],
        [
            'title' => 'CargoTrack Sistem Ekspedisi & Gudang',
            'slug' => 'cargotrack-ekspedisi-gudang',
            'category_id' => $cat_ids['Logistik & Ekspedisi'],
            'price' => 4200000,
            'price_label' => 'Mulai dari',
            'image' => 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=700&q=80',
            'description' => 'Sistem manajemen ekspedisi cargo, cetak resi thermal barcode, tracking paket realtime untuk pelanggan, dan penagihan invoice B2B.',
            'full_description' => 'Kelola armada pengiriman, manifesto muatan, perhitungan ongkir berdasarkan volume/berat aktual, serta fitur cek resi publik langsung dari halaman depan website perusahaan ekspedisi.',
            'features' => "Cetak Resi Barcode Format Thermal\nCek Resi & Status Kiriman Realtime Publik\nManajemen Manifest Muatan & Surat Jalan Driver\nInvoicing Tagihan B2B & Status Pembayaran\nLaporan Performa Pengiriman per Armada",
            'tech_stack' => 'PHP 8, Tailwind CSS, SQLite/MySQL',
            'platform' => 'Web App Responsive',
            'version' => 'v1.7.2',
            'license' => 'Lisensi Bisnis Ekspedisi',
            'demo_url' => 'https://cargo-demo.multiapps.id',
            'is_featured' => 0,
            'is_active' => 1
        ]
    ];

    $app_stmt = $pdo->prepare("INSERT INTO apps (
        title, slug, category_id, price, price_label, image, description, full_description, 
        features, tech_stack, platform, version, license, demo_url, is_featured, is_active
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    foreach ($apps as $app) {
        $app_stmt->execute([
            $app['title'],
            $app['slug'],
            $app['category_id'],
            $app['price'],
            $app['price_label'],
            $app['image'],
            $app['description'],
            $app['full_description'],
            $app['features'],
            $app['tech_stack'],
            $app['platform'],
            $app['version'],
            $app['license'],
            $app['demo_url'],
            $app['is_featured'],
            $app['is_active']
        ]);
    }

    // 5. Seed Testimonials
    $testimonials = [
        [
            'client_name' => 'Ahmad Hidayat',
            'client_role' => 'Owner Retail Mart',
            'company' => 'PT Hidayat Retail Abadi',
            'avatar' => 'AH',
            'review' => 'Aplikasi Kasir POS dari MultiApps Solutions sangat membantu 5 cabang ritel toko saya. Laporan stok real-time sangat akurat dan mudah dioperasikan kasir baru.',
            'rating' => 5
        ],
        [
            'client_name' => 'Rina Kusuma',
            'client_role' => 'HR Manager',
            'company' => 'PT Synergy Kreasi Mandiri',
            'avatar' => 'RK',
            'review' => 'Integrasi sistem HRIS untuk 100+ karyawan kami berjalan lancar dalam hitungan hari. Absensi GPS anti-fake membuat disiplin kerja melonjak drastis.',
            'rating' => 5
        ],
        [
            'client_name' => 'Budi Wijaya',
            'client_role' => 'Direktur Operasional',
            'company' => 'Logistics Express Nusantara',
            'avatar' => 'BW',
            'review' => 'Fitur pesanan kustom luar biasa. Tim MultiApps responsif dan siap membantu hingga aplikasi terpasang sempurna di hosting kami. Sangat direkomendasikan!',
            'rating' => 5
        ]
    ];

    $testi_stmt = $pdo->prepare("INSERT INTO testimonials (client_name, client_role, company, avatar, review, rating) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($testimonials as $t) {
        $testi_stmt->execute([$t['client_name'], $t['client_role'], $t['company'], $t['avatar'], $t['review'], $t['rating']]);
    }

    // 6. Seed FAQs
    $faqs = [
        [
            'question' => 'Apakah aplikasi ini bisa dipasang di hosting Rumahweb?',
            'answer' => 'Ya, 100%! Aplikasi ini dirancang khusus menggunakan PHP murni dan database SQLite modern. Tidak membutuhkan konfigurasi MySQL yang rumit. Anda cukup mengunggah file ke File Manager cPanel Rumahweb pada folder public_html, dan website langsung aktif seketika.',
            'sort' => 1
        ],
        [
            'question' => 'Apakah saya mendapatkan source code lengkap?',
            'answer' => 'Tentu. Setiap pembelian paket aplikasi menyertakan full source code tanpa enkripsi (open source code), sehingga Anda bebas mengembangkan lebih lanjut atau melakukan kustomisasi di masa depan.',
            'sort' => 2
        ],
        [
            'question' => 'Bagaimana jika saya memerlukan fitur tambahan atau kustomisasi khusus?',
            'answer' => 'Tim developer MultiApps Solutions menyediakan layanan kustomisasi dan penambahan modul sesuai kebutuhan spesifik proses bisnis Anda. Silakan hubungi kami via WhatsApp atau formulir konsultasi.',
            'sort' => 3
        ],
        [
            'question' => 'Apakah ada garansi dan bantuan instalasi?',
            'answer' => 'Ya, kami memberikan garansi bebas bug serta pendampingan instalasi gratis sampai aplikasi live di hosting atau server Anda.',
            'sort' => 4
        ]
    ];

    $faq_stmt = $pdo->prepare("INSERT INTO faqs (question, answer, sort_order) VALUES (?, ?, ?)");
    foreach ($faqs as $f) {
        $faq_stmt->execute([$f['question'], $f['answer'], $f['sort']]);
    }

    // 7. Seed Sample Initial Inquiries
    $sample_inquiries = [
        [
            'invoice_code' => 'INQ-' . date('Ymd') . '-001',
            'app_id' => 1,
            'app_name' => 'Smart POS Resto Pro',
            'customer_name' => 'Hendra Pratama',
            'customer_phone' => '081298765432',
            'customer_email' => 'hendra@restoberkah.com',
            'company' => 'Cafe & Resto Berkah',
            'message' => 'Halo, saya tertarik dengan POS Resto Pro untuk 2 cabang cafe di Bandung. Apakah bisa sekalian disettingkan printer thermal dan QR menu meja?',
            'budget' => 'Rp 2.000.000 - Rp 3.000.000',
            'status' => 'Baru',
            'admin_notes' => ''
        ],
        [
            'invoice_code' => 'INQ-' . date('Ymd') . '-002',
            'app_id' => 2,
            'app_name' => 'Omni HRIS & Payroll Cloud',
            'customer_name' => 'Dewi Anggraini',
            'customer_phone' => '085712349988',
            'customer_email' => 'dewi.hr@nusantaracorp.id',
            'company' => 'Nusantara Corp',
            'message' => 'Mohon info detail perhitungan PPh 21 tarif TER terbaru untuk sistem HRIS ini.',
            'budget' => 'Rp 3.500.000 - Rp 5.000.000',
            'status' => 'Diproses',
            'admin_notes' => 'Sudah dikontak via WA, menunggu jadwal demo online hari Rabu.'
        ]
    ];

    $inq_stmt = $pdo->prepare("INSERT INTO inquiries (
        invoice_code, app_id, app_name, customer_name, customer_phone, customer_email, company, message, budget, status, admin_notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    foreach ($sample_inquiries as $inq) {
        $inq_stmt->execute([
            $inq['invoice_code'], $inq['app_id'], $inq['app_name'], $inq['customer_name'],
            $inq['customer_phone'], $inq['customer_email'], $inq['company'], $inq['message'],
            $inq['budget'], $inq['status'], $inq['admin_notes']
        ]);
    }
}

// Helper: Get specific setting value
function get_setting($key, $default = '') {
    $pdo = get_db();
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    return $row ? $row['setting_value'] : $default;
}

// Helper: Set setting value
function set_setting($key, $value) {
    $pdo = get_db();
    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value");
    return $stmt->execute([$key, $value]);
}

// Helper: Get all settings as assoc array
function get_all_settings() {
    $pdo = get_db();
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = [];
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    return $settings;
}
